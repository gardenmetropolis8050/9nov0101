import { createServerFn } from "@tanstack/react-start";
import type { AnmeldungResult } from "@/lib/anmeldung.functions";
import { checkKontakt } from "@/lib/kontakt";
import { createPublicSupabase } from "@/lib/public-supabase";

/**
 * Public endpoint: stores one contact message in `kontakt_nachrichten`.
 * Uses the public key — RLS allows inserting only; nobody can read messages back.
 */
export const submitKontakt = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Ungültige Anfrage.");
    return input as Record<string, unknown>;
  })
  .handler(async ({ data }): Promise<AnmeldungResult> => {
    // Hidden trap field: real visitors leave it empty, bots tend to fill it.
    if (typeof data["website"] === "string" && data["website"].trim() !== "") return { status: "ok" };

    const check = checkKontakt(data);
    if (!check.ok) return { status: "invalid", invalid: check.invalid };

    try {
      const supabase = await createPublicSupabase();
      const { error } = await supabase.from("kontakt_nachrichten").insert(check.data);
      if (error) {
        console.error("Kontaktnachricht speichern fehlgeschlagen:", error.code, error.message);
        return { status: "failed" };
      }
      return { status: "ok" };
    } catch (e) {
      console.error("Kontaktnachricht speichern fehlgeschlagen:", e instanceof Error ? e.message : e);
      return { status: "failed" };
    }
  });
