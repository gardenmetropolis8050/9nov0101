import { z } from "zod";

// Rules for the contact form (`kontakt_nachrichten`). Used in the browser and on the server.
// Texts (labels, error messages) come from the database (`form_fields`, `content_blocks`).

export const kontaktSchema = z.object({
  name: z.string().trim().min(1).max(200),
  email: z.string().trim().max(255).email(),
  telefon: z
    .string()
    .trim()
    .max(50)
    .regex(/^[+\d\s()/.-]*$/)
    .optional()
    .transform((v) => (v ? v : null)),
  nachricht: z.string().trim().min(1).max(3000),
});

export type Kontakt = z.output<typeof kontaktSchema>;
const KONTAKT_FIELDS = Object.keys(kontaktSchema.shape) as Array<keyof Kontakt>;

export type KontaktCheck = { ok: true; data: Kontakt } | { ok: false; invalid: string[] };

/** Validates raw form values; returns clean data or the names of invalid fields. */
export function checkKontakt(raw: unknown): KontaktCheck {
  const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const values: Record<string, unknown> = {};
  for (const f of KONTAKT_FIELDS) {
    const v = source[f];
    values[f] = typeof v === "string" ? v : v == null ? undefined : String(v);
  }
  const result = kontaktSchema.safeParse(values);
  if (result.success) return { ok: true, data: result.data };
  return { ok: false, invalid: [...new Set(result.error.issues.map((i) => String(i.path[0])))] };
}
