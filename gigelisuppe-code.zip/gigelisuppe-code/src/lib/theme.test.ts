import { describe, expect, it } from "vitest";
import { themeFontUrls, themeToCss } from "./theme";

describe("theme from Supabase", () => {
  it("farbe_haupt sets the button color variable --primary", () => {
    expect(themeToCss({ farbe_haupt: "#c4506a" })).toContain("--primary:#c4506a");
  });

  it("rundung_px becomes --radius in px", () => {
    expect(themeToCss({ rundung_px: 20 })).toContain("--radius:20px");
  });

  it("ignores invalid color values so defaults stay in place", () => {
    expect(themeToCss({ farbe_haupt: "red;}body{display:none" })).toBe("");
  });

  it("falls back to no override when the theme could not be loaded", () => {
    expect(themeToCss(null)).toBe("");
  });

  it("loads each font from Google Fonts", () => {
    expect(themeFontUrls({ schrift_titel: "Fredoka", schrift_text: "Nunito" })).toEqual([
      "https://fonts.googleapis.com/css2?family=Fredoka:wght@400;700&display=swap",
      "https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap",
    ]);
  });
});
