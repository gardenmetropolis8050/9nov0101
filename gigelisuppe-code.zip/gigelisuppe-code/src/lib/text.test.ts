import { describe, expect, it } from "vitest";
import { fillPlaceholders, formatLongDate, parseInlineLinks, sectionYear } from "./text";

describe("Feiertage", () => {
  it("formats dates like the original page", () => {
    expect(formatLongDate("2026-01-01")).toBe("Donnerstag, 1. Januar 2026");
    expect(formatLongDate("2026-12-24")).toBe("Donnerstag, 24. Dezember 2026");
  });
  it("takes the year from the section heading", () => {
    expect(sectionYear("2026")).toBe(2026);
    expect(sectionYear(null)).toBeNull();
  });
});

describe("fillPlaceholders", () => {
  it("fills setting keys and the current year", () => {
    expect(fillPlaceholders("© {{jahr}} {{firma}}", { firma: "Gigelisuppe GmbH" }, 2026)).toBe(
      "© 2026 Gigelisuppe GmbH",
    );
  });
  it("leaves unknown keys empty", () => {
    expect(fillPlaceholders("a{{fehlt}}b", {})).toBe("ab");
  });
});

describe("parseInlineLinks", () => {
  it("splits markdown links from text", () => {
    expect(parseInlineLinks("Tel: [044 262 65 95](tel:+41442626595)!")).toEqual([
      { type: "text", text: "Tel: " },
      { type: "link", text: "044 262 65 95", href: "tel:+41442626595" },
      { type: "text", text: "!" },
    ]);
  });
});
