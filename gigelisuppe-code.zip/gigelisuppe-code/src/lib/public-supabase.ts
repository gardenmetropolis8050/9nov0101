import type { Database } from "@/integrations/supabase/types";

// Read-only Supabase client for public content. Call only inside server-function
// handlers: it reads server env vars and keeps no session.
export async function createPublicSupabase() {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Supabase ist nicht konfiguriert (URL/Key fehlt).");

  const { createClient } = await import("@supabase/supabase-js");
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      // sb_publishable_ keys are opaque, not JWTs: send them only as apikey.
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
}
