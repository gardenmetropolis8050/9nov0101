// Small, browser-safe helpers for texts that come from Supabase.

/** Replaces {{key}} with values from site settings; {{jahr}} is the current year. */
export function fillPlaceholders(
  text: string,
  vars: Record<string, string>,
  year = new Date().getFullYear(),
): string {
  return text.replace(/\{\{\s*([a-z0-9_]+)\s*\}\}/gi, (_m, key: string) =>
    key === "jahr" ? String(year) : (vars[key] ?? ""),
  );
}

export type InlinePart = { type: "text"; text: string } | { type: "link"; text: string; href: string };

/** Splits a line into plain text and markdown links `[label](url)`. */
export function parseInlineLinks(line: string): InlinePart[] {
  const parts: InlinePart[] = [];
  const re = /\[([^\]]+)\]\(([^)\s]+)\)/g;
  let last = 0;
  for (let m = re.exec(line); m; m = re.exec(line)) {
    if (m.index > last) parts.push({ type: "text", text: line.slice(last, m.index) });
    parts.push({ type: "link", text: m[1] ?? "", href: m[2] ?? "" });
    last = m.index + m[0].length;
  }
  if (last < line.length) parts.push({ type: "text", text: line.slice(last) });
  return parts;
}

/** "2026-01-01" -> "Donnerstag, 1. Januar 2026" (date only, no time-zone shift). */
export function formatLongDate(isoDate: string): string {
  const d = new Date(`${isoDate}T00:00:00Z`);
  if (Number.isNaN(d.getTime())) return isoDate;
  return new Intl.DateTimeFormat("de-CH", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(d);
}

/** Year shown by a holiday list section: a 4-digit number in its heading, else null. */
export function sectionYear(heading: string | null | undefined): number | null {
  const m = heading?.match(/\b(\d{4})\b/);
  return m ? Number(m[1]) : null;
}

/** Public URL of a file in a public Supabase storage bucket (browser-reachable host). */
export function storageUrl(bucket: string, path: string): string {
  const base = String(import.meta.env["VITE_SUPABASE_URL"] ?? "").replace(/\/$/, "");
  const cleanPath = path.split("/").map(encodeURIComponent).join("/");
  return `${base}/storage/v1/object/public/${encodeURIComponent(bucket)}/${cleanPath}`;
}
