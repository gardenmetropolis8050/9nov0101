import { createServerFn } from "@tanstack/react-start";
import { checkAnmeldung } from "@/lib/anmeldung";
import { createPublicSupabase } from "@/lib/public-supabase";

export type AnmeldungResult = { status: "ok" } | { status: "invalid"; invalid: string[] } | { status: "failed" };

/**
 * Public endpoint: stores one registration in `anmeldungen`.
 * Uses the public key — RLS allows inserting only; nobody can read registrations back.
 */
export const submitAnmeldung = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Ungültige Anfrage.");
    return input as Record<string, unknown>;
  })
  .handler(async ({ data }): Promise<AnmeldungResult> => {
    // Hidden trap field: real visitors leave it empty, bots tend to fill it.
    if (typeof data["website"] === "string" && data["website"].trim() !== "") return { status: "ok" };

    const check = checkAnmeldung(data);
    if (!check.ok) return { status: "invalid", invalid: check.invalid };

    try {
      const supabase = await createPublicSupabase();
      const { error } = await supabase.from("anmeldungen").insert(check.data);
      if (error) {
        console.error("Anmeldung speichern fehlgeschlagen:", error.code, error.message);
        return { status: "failed" };
      }
      return { status: "ok" };
    } catch (e) {
      console.error("Anmeldung speichern fehlgeschlagen:", e instanceof Error ? e.message : e);
      return { status: "failed" };
    }
  });
