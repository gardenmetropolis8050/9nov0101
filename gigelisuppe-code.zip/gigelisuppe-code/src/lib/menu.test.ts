import { describe, expect, it } from "vitest";
import { buildMenus, type Menus, type NavigationRow } from "./menu";

const get = (m: Menus, k: string) => m[k] ?? [];
const at = <T,>(a: T[], i: number): T => {
  const v = a[i];
  if (v === undefined) throw new Error(`missing item ${i}`);
  return v;
};

const row = (r: Partial<NavigationRow> & Pick<NavigationRow, "id" | "label">): NavigationRow => ({
  menu: "hauptmenue",
  url: null,
  parent_id: null,
  open_in_new_tab: false,
  sort_order: 1,
  page_path: null,
  ...r,
});

describe("buildMenus", () => {
  it("groups by menu, nests children under parents and sorts by sort_order", () => {
    const menus = buildMenus([
      row({ id: 3, label: "Tarife", parent_id: 2, sort_order: 2, page_path: "/tarife" }),
      row({ id: 2, label: "Angebot", sort_order: 2 }),
      row({ id: 1, label: "Home", sort_order: 1, page_path: "/" }),
      row({ id: 4, label: "Tagesablauf", parent_id: 2, sort_order: 1 }),
      row({ id: 9, label: "Impressum", menu: "footer", url: "/impressum" }),
    ]);
    expect(get(menus, "hauptmenue").map((i) => i.label)).toEqual(["Home", "Angebot"]);
    expect(at(get(menus, "hauptmenue"), 1).children.map((i) => i.label)).toEqual(["Tagesablauf", "Tarife"]);
    expect(at(at(get(menus, "hauptmenue"), 1).children, 1).href).toBe("/tarife");
    expect(get(menus, "footer").map((i) => i.href)).toEqual(["/impressum"]);
  });

  it("prefers an explicit url over the linked page path", () => {
    const menus = buildMenus([row({ id: 1, label: "X", url: "https://a.ch", page_path: "/x" })]);
    expect(at(get(menus, "hauptmenue"), 0).href).toBe("https://a.ch");
  });
});
