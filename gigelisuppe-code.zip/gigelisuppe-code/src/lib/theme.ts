// Turns the `theme` row from Supabase into CSS variables and Google Fonts links.
// Pure and browser-safe; the database read lives in theme.functions.ts.

export type ThemeRow = {
  farbe_hintergrund: string;
  farbe_karte: string;
  farbe_text: string;
  farbe_text_leise: string;
  farbe_haupt: string;
  farbe_haupt_text: string;
  farbe_akzent_rosa: string;
  farbe_akzent_blau: string;
  farbe_akzent_mint: string;
  farbe_akzent_gelb: string;
  farbe_akzent_gruen: string;
  farbe_rand: string;
  farbe_banner: string;
  schrift_titel: string;
  schrift_text: string;
  rundung_px: number;
  schatten_staerke: number;
};

// Column -> CSS variable. Derived shadcn tokens (card-foreground, ring, ...) are
// wired to these in styles.css, so only the base variables are overridden here.
const COLOR_VARS: Array<[keyof ThemeRow, string]> = [
  ["farbe_hintergrund", "--background"],
  ["farbe_karte", "--card"],
  ["farbe_text", "--foreground"],
  ["farbe_text_leise", "--muted-foreground"],
  ["farbe_haupt", "--primary"],
  ["farbe_haupt_text", "--primary-foreground"],
  ["farbe_akzent_rosa", "--rosa"],
  ["farbe_akzent_blau", "--hellblau"],
  ["farbe_akzent_mint", "--mint"],
  ["farbe_akzent_gelb", "--sonne"],
  ["farbe_akzent_gruen", "--blatt"],
  ["farbe_rand", "--border"],
  ["farbe_banner", "--banner"],
];

const HEX = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const FONT_NAME = /^[A-Za-z0-9 ]{1,60}$/;

function cleanFont(name: unknown): string | null {
  if (typeof name !== "string") return null;
  const trimmed = name.trim();
  return FONT_NAME.test(trimmed) ? trimmed : null;
}

/** Builds the `:root{...}` override. Invalid values are skipped so the CSS defaults apply. */
export function themeToCss(theme: Partial<ThemeRow> | null | undefined): string {
  if (!theme) return "";
  const decls: string[] = [];

  for (const [column, cssVar] of COLOR_VARS) {
    const value = theme[column];
    if (typeof value === "string" && HEX.test(value.trim())) {
      decls.push(`${cssVar}:${value.trim()}`);
    }
  }

  const radius = Number(theme.rundung_px);
  if (theme.rundung_px != null && Number.isFinite(radius) && radius >= 0 && radius <= 200) {
    decls.push(`--radius:${radius}px`);
  }

  const shadow = Number(theme.schatten_staerke);
  if (theme.schatten_staerke != null && Number.isFinite(shadow) && shadow >= 0 && shadow <= 1) {
    decls.push(`--schatten-staerke:${shadow}`);
  }

  const titel = cleanFont(theme.schrift_titel);
  if (titel) decls.push(`--font-titel-name:"${titel}"`);
  const text = cleanFont(theme.schrift_text);
  if (text) decls.push(`--font-text-name:"${text}"`);

  return decls.length ? `:root{${decls.join(";")}}` : "";
}

// Fallback only, used when the theme row cannot be loaded; must match the defaults in styles.css.
export const FALLBACK_FONTS: Pick<ThemeRow, "schrift_titel" | "schrift_text"> = {
  schrift_titel: "Fredoka",
  schrift_text: "Nunito",
};

/** One Google Fonts stylesheet URL per valid font, so one bad name cannot break the other. */
export function themeFontUrls(theme: Partial<ThemeRow> | null | undefined): string[] {
  const names = [cleanFont(theme?.schrift_titel), cleanFont(theme?.schrift_text)].filter(
    (n): n is string => !!n,
  );
  return [...new Set(names)].map(
    (name) =>
      `https://fonts.googleapis.com/css2?family=${encodeURIComponent(name).replace(/%20/g, "+")}:wght@400;700&display=swap`,
  );
}
