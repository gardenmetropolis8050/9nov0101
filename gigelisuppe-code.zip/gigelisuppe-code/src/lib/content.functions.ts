// Central data access for website content. All reads go through server functions
// with the public (read-only) Supabase client; RLS decides what is visible.
import { createServerFn } from "@tanstack/react-start";
import { queryOptions } from "@tanstack/react-query";
import { notFound } from "@tanstack/react-router";
import { buildMenus, type Menus, type NavigationRow } from "./menu";
import { createPublicSupabase } from "./public-supabase";
import { sectionYear } from "./text";

const STALE_TIME = 60 * 1000;

function fail(what: string, message: string): never {
  console.error(`[content] ${what} konnte nicht geladen werden:`, message);
  throw new Error(`${what} konnte nicht geladen werden.`);
}

// --- Einstellungen (site_settings) ------------------------------------------

export type Settings = Record<string, string>;

export const getSettings = createServerFn({ method: "GET" }).handler(
  async (): Promise<Settings> => {
    const supabase = await createPublicSupabase();
    const { data, error } = await supabase
      .from("site_settings")
      .select("key,value")
      .order("sort_order");
    if (error) fail("Einstellungen", error.message);
    return Object.fromEntries((data ?? []).map((r) => [r.key, r.value]));
  },
);

export const settingsQueryOptions = () =>
  queryOptions({ queryKey: ["settings"], queryFn: () => getSettings(), staleTime: STALE_TIME });

// --- Menü (navigation + pages) ----------------------------------------------

export const getMenus = createServerFn({ method: "GET" }).handler(async (): Promise<Menus> => {
  const supabase = await createPublicSupabase();
  const { data, error } = await supabase
    .from("navigation")
    .select("id,menu,label,url,parent_id,open_in_new_tab,sort_order,pages(path)")
    .eq("is_visible", true);
  if (error) fail("Menü", error.message);
  const rows: NavigationRow[] = (data ?? []).map((r) => ({
    id: r.id,
    menu: r.menu,
    label: r.label,
    url: r.url,
    parent_id: r.parent_id,
    open_in_new_tab: r.open_in_new_tab,
    sort_order: r.sort_order,
    page_path: r.pages?.path ?? null,
  }));
  return buildMenus(rows);
});

export const menusQueryOptions = () =>
  queryOptions({ queryKey: ["menus"], queryFn: () => getMenus(), staleTime: STALE_TIME });

// --- Abschnitte (page_sections + Bausteine, Bilder, Angebote, Stimmen) ------

export type Block = {
  block_key: string | null;
  block_type: string;
  title: string | null;
  subtitle: string | null;
  content: string | null;
  button_text: string | null;
  button_url: string | null;
  button_style: string | null;
  link_target: string;
  icon: string | null;
  color_tone: string | null;
};

export type SectionImage = {
  bucket: string;
  path: string;
  alt: string | null;
  caption: string | null;
  usage: string;
  link: string | null;
  width: number | null;
  height: number | null;
};

export type Offer = {
  title: string | null;
  description: string;
  icon: string | null;
  color_tone: string | null;
};

export type Testimonial = { author: string | null; body: string; color_tone: string | null };

export type ScheduleEntry = { time_label: string; description: string };

export type FormField = {
  form_key: string;
  field_name: string;
  label: string;
  field_type: string;
  is_required: boolean;
  placeholder: string | null;
  autocomplete: string | null;
  rows: number | null;
  min_length: number | null;
  max_length: number | null;
  validation_message: string | null;
  full_width: boolean;
};

export type Faq = { question: string; answer: string; category: string };

export type Tariff = {
  label: string;
  child_category: string;
  price_display: string;
  unit_label: string | null;
  description: string | null;
};

export type TeamMember = {
  name: string;
  role: string;
  initials: string | null;
  photo: { bucket: string; path: string; alt: string | null } | null;
};

export type Holiday = {
  title: string;
  start_date: string;
  end_date: string;
  description: string;
};

export type Section = {
  section_key: string;
  section_type: string;
  eyebrow: string | null;
  heading: string | null;
  heading_level: string | null;
  content: string | null;
  color_tone: string | null;
  icon: string | null;
  blocks: Block[];
  images: SectionImage[];
  offers: Offer[];
  testimonials: Testimonial[];
  schedule: ScheduleEntry[];
  tariffs: Tariff[];
  faqs: Faq[];
  fields: FormField[];
  team: TeamMember[];
  /** Only for `holiday_list`: holidays of the year named in the heading (table `holidays`). */
  holidays: Holiday[];
};

const SECTION_SELECT =
  "section_key,section_type,eyebrow,heading,heading_level,content,color_tone,icon,sort_order," +
  "content_blocks(block_key,block_type,title,subtitle,content,button_text,button_url,button_style,link_target,icon,color_tone,sort_order)," +
  "section_images(usage_type,caption,link_url,sort_order,images(storage_bucket,storage_path,alt_text,width,height))," +
  "offers(title,description,icon,color_tone,sort_order)," +
  "testimonials(author,body,color_tone,sort_order)," +
  "schedule_entries(time_label,description,sort_order)," +
  "tariffs(label,child_category,price_display,unit_label,description,sort_order)," +
  "faq(question,answer,category,sort_order)," +
  "team_members(name,role,initials,sort_order,images(storage_bucket,storage_path,alt_text))," +
  "form_fields(form_key,field_name,label,field_type,is_required,placeholder,autocomplete,rows,min_length,max_length,validation_message,full_width,sort_order)";

type Sorted = { sort_order: number };
type RawSection = Omit<Section, "blocks" | "images" | "offers" | "testimonials" | "schedule" | "tariffs" | "faqs" | "fields" | "team" | "holidays"> &
  Sorted & {
    content_blocks: Array<Block & Sorted> | null;
    section_images: Array<
      Sorted & {
        usage_type: string;
        caption: string | null;
        link_url: string | null;
        images: {
          storage_bucket: string;
          storage_path: string;
          alt_text: string | null;
          width: number | null;
          height: number | null;
        } | null;
      }
    > | null;
    offers: Array<Offer & Sorted> | null;
    testimonials: Array<Testimonial & Sorted> | null;
    schedule_entries: Array<ScheduleEntry & Sorted> | null;
    tariffs: Array<Tariff & Sorted> | null;
    faq: Array<Faq & Sorted> | null;
    form_fields: Array<FormField & Sorted> | null;
    team_members: Array<
      Sorted & {
        name: string;
        role: string;
        initials: string | null;
        images: { storage_bucket: string; storage_path: string; alt_text: string | null } | null;
      }
    > | null;
  };

const bySort = <T extends Sorted>(a: T, b: T) => a.sort_order - b.sort_order;
const sorted = <T extends Sorted>(rows: T[] | null) => [...(rows ?? [])].sort(bySort);
const dropSort = <T extends Sorted>({ sort_order: _s, ...rest }: T) => rest;

function toSection(s: RawSection): Section {
  return {
    section_key: s.section_key,
    section_type: s.section_type,
    eyebrow: s.eyebrow,
    heading: s.heading,
    heading_level: s.heading_level,
    content: s.content,
    color_tone: s.color_tone,
    icon: s.icon,
    blocks: sorted(s.content_blocks).map(dropSort),
    images: sorted(s.section_images).flatMap((i) =>
      i.images
        ? [
            {
              bucket: i.images.storage_bucket,
              path: i.images.storage_path,
              alt: i.images.alt_text,
              caption: i.caption,
              usage: i.usage_type,
              link: i.link_url,
              width: i.images.width,
              height: i.images.height,
            },
          ]
        : [],
    ),
    offers: sorted(s.offers).map(dropSort),
    testimonials: sorted(s.testimonials).map(dropSort),
    schedule: sorted(s.schedule_entries).map(dropSort),
    tariffs: sorted(s.tariffs).map(dropSort),
    faqs: sorted(s.faq).map(dropSort),
    fields: sorted(s.form_fields).map(dropSort),
    team: sorted(s.team_members).map((m) => ({
      name: m.name,
      role: m.role,
      initials: m.initials,
      photo: m.images
        ? { bucket: m.images.storage_bucket, path: m.images.storage_path, alt: m.images.alt_text }
        : null,
    })),
    holidays: [],
  };
}

/** Fills `holidays` of every holiday_list section with the visible holidays of its year. */
async function attachHolidays(
  supabase: Awaited<ReturnType<typeof createPublicSupabase>>,
  sections: Section[],
): Promise<Section[]> {
  const years = [
    ...new Set(
      sections
        .filter((s) => s.section_type === "holiday_list")
        .map((s) => sectionYear(s.heading))
        .filter((y): y is number => y !== null),
    ),
  ];
  if (years.length === 0) return sections;
  const { data, error } = await supabase
    .from("holidays")
    .select("title,start_date,end_date,description,display_year,sort_order")
    .in("display_year", years)
    .eq("is_visible", true)
    .order("sort_order")
    .order("start_date");
  if (error) fail("Feiertage", error.message);
  return sections.map((s) => {
    if (s.section_type !== "holiday_list") return s;
    const year = sectionYear(s.heading);
    return {
      ...s,
      holidays: (data ?? [])
        .filter((h) => h.display_year === year)
        .map(({ title, start_date, end_date, description }) => ({ title, start_date, end_date, description })),
    };
  });
}

// --- Seite inkl. Abschnitte (pages + page_sections) -------------------------

export type Page = {
  slug: string;
  path: string | null;
  title: string;
  meta_title: string | null;
  meta_description: string | null;
  og_title: string | null;
  og_description: string | null;
  show_cta_section: boolean;
  cta_heading_override: string | null;
  sections: Section[];
};

export const getPage = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) => {
    const slug = String(input?.slug ?? "").trim();
    if (!/^[a-z0-9_-]{1,80}$/.test(slug)) throw new Error("Ungültige Seitenadresse.");
    return { slug };
  })
  .handler(async ({ data: { slug } }): Promise<Page | null> => {
    const supabase = await createPublicSupabase();
    const { data, error } = await supabase
      .from("pages")
      .select(
        `slug,path,title,meta_title,meta_description,og_title,og_description,show_cta_section,cta_heading_override,page_sections(${SECTION_SELECT})`,
      )
      .eq("slug", slug)
      .eq("is_published", true)
      .maybeSingle();
    if (error) fail(`Seite „${slug}“`, error.message);
    if (!data) return null;
    const { page_sections, ...page } = data as unknown as Omit<Page, "sections"> & {
      page_sections: RawSection[] | null;
    };
    return { ...page, sections: await attachHolidays(supabase, sorted(page_sections).map(toSection)) };
  });

/** Loads a page by slug; throws notFound() when it does not exist or is not published. */
export const pageQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["page", slug],
    queryFn: async () => {
      const page = await getPage({ data: { slug } });
      if (!page) throw notFound();
      return page;
    },
    staleTime: STALE_TIME,
  });

// --- Layout: globale Abschnitte (Kopf-/Fusszeile), Banner, Öffnungszeiten ----

export type Banner = { text: string; linkLabel: string | null; linkUrl: string | null };

export type Layout = {
  sections: Record<string, Section>;
  banner: Banner | null;
  openingHours: Section | null;
};

export const getLayout = createServerFn({ method: "GET" }).handler(async (): Promise<Layout> => {
  const supabase = await createPublicSupabase();
  const today = new Date().toISOString().slice(0, 10);

  const [global, banner, hours] = await Promise.all([
    supabase.from("pages").select(`page_sections(${SECTION_SELECT})`).eq("slug", "_global").maybeSingle(),
    supabase
      .from("availability")
      .select("description,banner_link_label,banner_link_url")
      .eq("is_visible", true)
      .eq("show_as_banner", true)
      .or(`available_until.is.null,available_until.gte.${today}`)
      .order("available_from")
      .limit(1)
      .maybeSingle(),
    supabase
      .from("page_sections")
      .select(SECTION_SELECT)
      .eq("section_type", "opening_hours")
      .order("sort_order")
      .limit(1)
      .maybeSingle(),
  ]);
  if (global.error) fail("Kopf- und Fusszeile", global.error.message);
  if (banner.error) fail("Banner", banner.error.message);
  if (hours.error) fail("Öffnungszeiten", hours.error.message);

  const sections: Record<string, Section> = {};
  const globalSections = (global.data as unknown as { page_sections: RawSection[] | null } | null)
    ?.page_sections;
  for (const s of sorted(globalSections ?? null)) sections[s.section_key] = toSection(s);

  return {
    sections,
    banner: banner.data
      ? {
          text: banner.data.description,
          linkLabel: banner.data.banner_link_label,
          linkUrl: banner.data.banner_link_url,
        }
      : null,
    openingHours: hours.data ? toSection(hours.data as unknown as RawSection) : null,
  };
});

export const layoutQueryOptions = () =>
  queryOptions({ queryKey: ["layout"], queryFn: () => getLayout(), staleTime: STALE_TIME });
