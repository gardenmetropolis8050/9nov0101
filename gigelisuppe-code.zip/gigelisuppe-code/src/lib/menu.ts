// Pure helper: turns flat `navigation` rows into menus grouped by `menu`,
// with sub-items nested under their parent, everything sorted by sort_order.

export type NavigationRow = {
  id: number;
  menu: string;
  label: string;
  url: string | null;
  parent_id: number | null;
  open_in_new_tab: boolean;
  sort_order: number;
  page_path: string | null;
};

export type MenuItem = {
  id: number;
  label: string;
  href: string | null;
  newTab: boolean;
  children: MenuItem[];
};

export type Menus = Record<string, MenuItem[]>;

export function buildMenus(rows: NavigationRow[]): Menus {
  const sorted = [...rows].sort((a, b) => a.sort_order - b.sort_order || a.id - b.id);
  const items = new Map<number, MenuItem>();
  for (const r of sorted) {
    items.set(r.id, {
      id: r.id,
      label: r.label,
      href: r.url ?? r.page_path,
      newTab: r.open_in_new_tab,
      children: [],
    });
  }

  const menus: Menus = {};
  for (const r of sorted) {
    const item = items.get(r.id)!;
    const parent = r.parent_id != null ? items.get(r.parent_id) : undefined;
    if (parent) parent.children.push(item);
    else (menus[r.menu] ??= []).push(item);
  }
  return menus;
}
