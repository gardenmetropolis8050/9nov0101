import { describe, expect, it } from "vitest";
import { checkKontakt } from "./kontakt";

const valid = { name: "Anna Muster", email: "anna@example.ch", telefon: "", nachricht: "Haben Sie im August Platz?" };

describe("checkKontakt", () => {
  it("accepts name, e-mail and message; phone is optional", () => {
    const r = checkKontakt(valid);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.data.telefon).toBeNull();
  });

  it("requires name, e-mail and message", () => {
    const r = checkKontakt({ name: " ", email: "", nachricht: "" });
    expect(r).toEqual({ ok: false, invalid: ["name", "email", "nachricht"] });
  });

  it("rejects an invalid e-mail address", () => {
    expect(checkKontakt({ ...valid, email: "anna@" })).toEqual({ ok: false, invalid: ["email"] });
  });

  it("rejects letters in the phone number", () => {
    expect(checkKontakt({ ...valid, telefon: "044 abc" })).toEqual({ ok: false, invalid: ["telefon"] });
  });

  it("rejects messages longer than 3000 characters", () => {
    expect(checkKontakt({ ...valid, nachricht: "a".repeat(3001) })).toEqual({ ok: false, invalid: ["nachricht"] });
  });
});
