import { describe, expect, it } from "vitest";
import { checkAnmeldung } from "./anmeldung";

const valid = {
  kind: "Mia Muster",
  geburtstag: "2025-03-14",
  email: "eltern@example.ch",
  telefon: "044 123 45 67",
  adresse: "Musterweg 1, 8008 Zürich",
  eintritt: "2026-08-17",
  eltern: "",
  tage: "Montag und Donnerstag",
  sonstiges: "",
};

describe("checkAnmeldung", () => {
  it("accepts a complete registration and turns empty optional fields into null", () => {
    const r = checkAnmeldung(valid);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.data.eltern).toBeNull();
      expect(r.data.sonstiges).toBeNull();
    }
  });

  it("requires child name, birthday, e-mail, phone, address, start date and days", () => {
    const r = checkAnmeldung({});
    expect(r.ok).toBe(false);
    if (!r.ok)
      expect(r.invalid.sort()).toEqual(["adresse", "eintritt", "email", "geburtstag", "kind", "tage", "telefon"]);
  });

  it("treats parents' name and other remarks as optional", () => {
    const { eltern: _e, sonstiges: _s, ...rest } = valid;
    expect(checkAnmeldung(rest).ok).toBe(true);
  });

  it("rejects an invalid e-mail address", () => {
    const r = checkAnmeldung({ ...valid, email: "keine-mail" });
    expect(r.ok ? [] : r.invalid).toEqual(["email"]);
  });

  it("rejects impossible dates", () => {
    const r = checkAnmeldung({ ...valid, geburtstag: "2025-02-30" });
    expect(r.ok ? [] : r.invalid).toEqual(["geburtstag"]);
  });

  it("rejects texts that are too long", () => {
    const r = checkAnmeldung({ ...valid, kind: "x".repeat(201), sonstiges: "y".repeat(2001) });
    expect(r.ok ? [] : r.invalid.sort()).toEqual(["kind", "sonstiges"]);
  });

  it("rejects a blank-only child name", () => {
    const r = checkAnmeldung({ ...valid, kind: "   " });
    expect(r.ok ? [] : r.invalid).toEqual(["kind"]);
  });
});
