import type { Page } from "./content.functions";

/** head() meta for a page from its SEO fields; noindex when the page did not load. */
export function pageHead(page: Page | undefined, url: string) {
  if (!page) {
    return { meta: [{ title: "Seite nicht gefunden" }, { name: "robots", content: "noindex" }] };
  }
  const title = page.meta_title ?? page.title;
  const description = page.meta_description ?? "";
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: page.og_title ?? title },
      { property: "og:description", content: page.og_description ?? description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: url },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: url }],
  };
}
