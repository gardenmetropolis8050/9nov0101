import { createServerFn } from "@tanstack/react-start";
import { queryOptions } from "@tanstack/react-query";
import type { ThemeRow } from "./theme";

// Public read of the single `theme` row. Returns null on any failure so the
// page falls back to the default design tokens instead of crashing.
export const getTheme = createServerFn({ method: "GET" }).handler(
  async (): Promise<ThemeRow | null> => {
    try {
      const url = process.env["SUPABASE_URL"];
      const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
      if (!url || !key) return null;

      const { createClient } = await import("@supabase/supabase-js");
      const supabase = createClient(url, key, {
        auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
        global: {
          // sb_publishable_ keys are opaque, not JWTs: send them only as apikey.
          fetch: (input, init) => {
            const headers = new Headers(init?.headers);
            if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
            headers.set("apikey", key);
            return fetch(input, { ...init, headers });
          },
        },
      });

      const { data, error } = await supabase
        .from("theme")
        .select(
          "farbe_hintergrund,farbe_karte,farbe_text,farbe_text_leise,farbe_haupt,farbe_haupt_text,farbe_akzent_rosa,farbe_akzent_blau,farbe_akzent_mint,farbe_akzent_gelb,farbe_akzent_gruen,farbe_rand,farbe_banner,schrift_titel,schrift_text,rundung_px,schatten_staerke",
        )
        .eq("id", 1)
        .maybeSingle();

      if (error) {
        console.error("[theme] load failed:", error.message);
        return null;
      }
      return (data as ThemeRow | null) ?? null;
    } catch (err) {
      console.error("[theme] load failed:", err);
      return null;
    }
  },
);

export const themeQueryOptions = () =>
  queryOptions({
    queryKey: ["theme"],
    queryFn: () => getTheme(),
    staleTime: 5 * 60 * 1000,
  });
