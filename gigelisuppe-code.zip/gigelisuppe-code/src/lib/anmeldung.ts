import { z } from "zod";

// Rules for the registration form (`anmeldungen`). Used in the browser and on the server.
// Texts (labels, error messages) come from the database (`form_fields`, `content_blocks`).

const isoDate = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((v) => !Number.isNaN(Date.parse(`${v}T00:00:00Z`)) && new Date(`${v}T00:00:00Z`).toISOString().startsWith(v));

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((v) => (v ? v : null));

export const anmeldungSchema = z.object({
  kind: z.string().trim().min(1).max(200),
  geburtstag: isoDate,
  email: z.string().trim().max(255).email(),
  telefon: z.string().trim().min(3).max(50),
  adresse: z.string().trim().min(1).max(300),
  eintritt: isoDate,
  eltern: optionalText(200),
  tage: z.string().trim().min(1).max(500),
  sonstiges: optionalText(2000),
});

export type Anmeldung = z.output<typeof anmeldungSchema>;
export const ANMELDUNG_FIELDS = Object.keys(anmeldungSchema.shape) as Array<keyof Anmeldung>;

export type AnmeldungCheck = { ok: true; data: Anmeldung } | { ok: false; invalid: string[] };

/** Validates raw form values; returns clean data or the names of invalid fields. */
export function checkAnmeldung(raw: unknown): AnmeldungCheck {
  const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const values: Record<string, unknown> = {};
  for (const f of ANMELDUNG_FIELDS) {
    const v = source[f];
    values[f] = typeof v === "string" ? v : v == null ? undefined : String(v);
  }
  const result = anmeldungSchema.safeParse(values);
  if (result.success) return { ok: true, data: result.data };
  const invalid = [...new Set(result.error.issues.map((i) => String(i.path[0])))];
  return { ok: false, invalid };
}
