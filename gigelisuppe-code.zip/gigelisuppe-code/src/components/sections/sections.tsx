import { Mail, MapPin, Phone, Quote } from "lucide-react";
import { useState, type CSSProperties } from "react";
import type { Section } from "@/lib/content.functions";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { formatLongDate, storageUrl } from "@/lib/text";
import { cn } from "@/lib/utils";
import {
  BlockButtons,
  BlockLink,
  CheckList,
  DbIcon,
  Markdown,
  SectionHeading,
  cardBase,
  cycleTone,
  toneBg,
  toneDot,
  toneVar,
} from "./shared";

type Props = { section: Section };

const gridCols = (n: number) =>
  n >= 3 ? "md:grid-cols-2 lg:grid-cols-3" : n === 2 ? "md:grid-cols-2" : "";

/** hero – page header with eyebrow, title, intro, buttons and optional picture. */
export function HeroSection({ section: s }: Props) {
  const image = s.images.find((i) => i.usage === "hero");
  return (
    <section
      className="farbwolken relative overflow-hidden"
      style={{ "--wolke": toneVar(s.color_tone) } as CSSProperties}
    >
      <div
        className={cn(
          "mx-auto grid max-w-6xl items-center gap-12 px-5 pb-10 pt-16 md:pt-20",
          image && "lg:grid-cols-2 lg:pb-16",
        )}
      >
        <div>
          {s.eyebrow && (
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">{s.eyebrow}</p>
          )}
          {s.heading && (
            <SectionHeading level={s.heading_level ?? "h1"} className="mt-4 text-4xl leading-tight md:text-5xl">
              {s.heading}
            </SectionHeading>
          )}
          <Markdown text={s.content} className="mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground" />
          <BlockButtons blocks={s.blocks} className="mt-8" />
        </div>
        {image && (
          <div className="relative">
            <span className="absolute -right-4 -top-4 size-24 rounded-full bg-sonne" aria-hidden="true" />
            <img
              src={storageUrl(image.bucket, image.path)}
              alt={image.alt ?? ""}
              width={image.width ?? undefined}
              height={image.height ?? undefined}
              className="relative aspect-[4/3] w-full rounded-[2rem] object-cover shadow-weich"
              fetchPriority="high"
            />
          </div>
        )}
      </div>
    </section>
  );
}

/** text – heading plus longer markdown text (e.g. legal texts). */
export function TextSection({ section: s }: Props) {
  return (
    <section className="max-w-3xl">
      {s.heading && (
        <SectionHeading level={s.heading_level} className="text-2xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="mt-3 leading-relaxed" />
    </section>
  );
}

/** karten (single) – one rounded card with text, check list and links. */
export function CardSection({ section: s }: Props) {
  const paragraphs = s.blocks.filter((b) => b.block_type === "paragraph");
  const items = [
    ...s.blocks.filter((b) => b.block_type === "list_item").map((b) => b.content ?? ""),
    ...s.offers.map((o) => (o.title ? `**${o.title}** – ${o.description}` : o.description)),
  ].filter(Boolean);
  const links = s.blocks.filter((b) => b.block_type === "link");
  return (
    <section className={cn(cardBase, toneBg(s.color_tone), "p-8 md:p-10")}>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="flex items-center gap-3 text-2xl md:text-3xl">
          <DbIcon name={s.icon} className="size-7 text-primary" />
          {s.heading}
        </SectionHeading>
      )}
      <div className={cn("space-y-4 leading-relaxed", s.heading && "mt-5")}>
        <Markdown text={s.content} />
        {paragraphs.map((b, i) => (
          <Markdown key={i} text={b.content} />
        ))}
        <CheckList items={items} />
        {links.map((b, i) => (
          <p key={i}>
            <BlockLink block={b} />
          </p>
        ))}
      </div>
    </section>
  );
}

/** karten (group) – intro text and a grid of coloured cards. */
export function CardsSection({ section: s }: Props) {
  const cards = s.blocks.filter((b) => b.title || b.content);
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="mb-6 text-lg" />
      <div className={cn("grid gap-6", gridCols(cards.length))}>
        {cards.map((c, i) => (
          <article key={i} className={cn(cardBase, toneBg(cycleTone(c.color_tone, i)), "p-8")}>
            {c.subtitle && <p className="mb-1 text-sm text-primary">{c.subtitle}</p>}
            {c.title && (
              <h3 className="flex items-center gap-2 text-xl font-semibold text-foreground">
                <DbIcon name={c.icon} className="size-5 text-primary" />
                {c.title}
              </h3>
            )}
            <Markdown text={c.content} className="mt-3 leading-relaxed" />
          </article>
        ))}
      </div>
    </section>
  );
}

/** text_bild – picture next to stacked cards. */
export function ImageCardsSection({ section: s }: Props) {
  const image = s.images[0];
  const cards = s.blocks.filter((b) => b.title || b.content);
  return (
    <section className="grid items-start gap-8 lg:grid-cols-2">
      <div>
        {s.heading && (
          <SectionHeading level={s.heading_level} className="mb-5 text-3xl">
            {s.heading}
          </SectionHeading>
        )}
        <Markdown text={s.content} className="mb-6 leading-relaxed" />
        {image && (
          <img
            src={storageUrl(image.bucket, image.path)}
            alt={image.alt ?? ""}
            width={image.width ?? undefined}
            height={image.height ?? undefined}
            className="w-full rounded-[2rem] object-cover shadow-weich"
            loading="lazy"
          />
        )}
      </div>
      <div className="space-y-5">
        {cards.map((c, i) => (
          <article key={i} className={cn(cardBase, toneBg(cycleTone(c.color_tone, i)), "p-6 md:p-7")}>
            {c.title && <h3 className="text-xl font-semibold text-foreground">{c.title}</h3>}
            <Markdown text={c.content} className="mt-3 leading-relaxed" />
          </article>
        ))}
      </div>
    </section>
  );
}

/** liste – intro sentence and coloured tags. */
export function TagListSection({ section: s }: Props) {
  const items = s.blocks.filter((b) => b.block_type === "list_item" && b.content);
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-4 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="text-lg" />
      <ul className="mt-5 flex flex-wrap gap-3">
        {items.map((b, i) => (
          <li
            key={i}
            className={cn("rounded-full px-5 py-2 font-titel text-lg text-foreground", toneBg(cycleTone(b.color_tone, i)))}
          >
            {b.content}
          </li>
        ))}
      </ul>
    </section>
  );
}

/** galerie – grid of pictures with captions; lazy-loaded, click opens the picture large. */
export function GallerySection({ section: s }: Props) {
  const [open, setOpen] = useState<number | null>(null);
  if (s.images.length === 0) return null;
  const big = open === null ? null : s.images[open];
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {s.images.map((img, i) => (
          <li key={i}>
            <figure className="overflow-hidden rounded-3xl bg-card shadow-weich">
              <button
                type="button"
                onClick={() => setOpen(i)}
                className="block w-full cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <img
                  src={storageUrl(img.bucket, img.path)}
                  alt={img.alt ?? img.caption ?? ""}
                  width={img.width ?? undefined}
                  height={img.height ?? undefined}
                  className="aspect-[8/3] w-full object-cover transition-transform duration-300 hover:scale-105"
                  loading="lazy"
                  decoding="async"
                />
              </button>
              {img.caption && (
                <figcaption className="px-3 py-2 text-sm text-muted-foreground">{img.caption}</figcaption>
              )}
            </figure>
          </li>
        ))}
      </ul>
      <Dialog open={big !== null} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent className="max-w-5xl border-none bg-card p-2 sm:rounded-3xl">
          <DialogTitle className="sr-only">{big?.caption ?? big?.alt ?? s.heading ?? ""}</DialogTitle>
          <DialogDescription className="sr-only">{big?.alt ?? ""}</DialogDescription>
          {big && (
            <figure>
              <img
                src={storageUrl(big.bucket, big.path)}
                alt={big.alt ?? big.caption ?? ""}
                className="max-h-[80vh] w-full rounded-2xl object-contain"
              />
              {big.caption && (
                <figcaption className="px-2 pt-2 text-sm text-muted-foreground">{big.caption}</figcaption>
              )}
            </figure>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

/** zitat – quotes (e.g. parents' voices). */
export function QuoteSection({ section: s }: Props) {
  if (s.testimonials.length === 0 && !s.content) return null;
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="mb-6 text-lg" />
      <div className="gap-6 md:columns-2">
        {s.testimonials.map((t, i) => (
          <figure key={i} className={cn(cardBase, toneBg(cycleTone(t.color_tone, i)), "mb-6 break-inside-avoid p-8")}>
            <Quote className="size-7 text-primary" aria-hidden="true" />
            <blockquote className="mt-3 leading-relaxed">
              <Markdown text={t.body} />
            </blockquote>
            {t.author && <figcaption className="mt-4 font-titel text-lg text-himmel">– {t.author}</figcaption>}
          </figure>
        ))}
      </div>
    </section>
  );
}

/** info_box – small coloured box with bullet points or text. */
export function InfoBoxSection({ section: s }: Props) {
  const items = s.blocks.filter((b) => b.block_type === "list_item" && b.content);
  const paragraphs = s.blocks.filter((b) => b.block_type === "paragraph");
  return (
    <aside className={cn("rounded-3xl p-6 md:p-7", toneBg(s.color_tone, "bg-hellblau"))}>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="text-xl">
          {s.heading}
        </SectionHeading>
      )}
      <div className="mt-3 space-y-3 leading-relaxed">
        <Markdown text={s.content} />
        {items.length > 0 && (
          <ul className="list-disc space-y-2 pl-5">
            {items.map((b, i) => (
              <li key={i}>
                <Markdown text={b.content} />
              </li>
            ))}
          </ul>
        )}
        {paragraphs.map((b, i) => (
          <Markdown key={i} text={b.content} />
        ))}
      </div>
    </aside>
  );
}

/** aufruf – call to action band with button. */
export function CtaSection({ section: s, headingOverride }: Props & { headingOverride?: string | null }) {
  const heading = headingOverride || s.heading;
  return (
    <section className={cn("relative overflow-hidden rounded-[2rem] p-10 md:p-12", toneBg(s.color_tone, "bg-rosa"))}>
      <span className="absolute -right-16 -top-16 size-56 rounded-full bg-hellblau/80" aria-hidden="true" />
      <span className="absolute -bottom-20 right-32 size-36 rounded-full bg-sonne/40" aria-hidden="true" />
      <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div>
          {heading && (
            <SectionHeading level={s.heading_level} className="text-3xl">
              {heading}
            </SectionHeading>
          )}
          <Markdown text={s.content} className="mt-2 text-muted-foreground" />
        </div>
        <BlockButtons blocks={s.blocks} />
      </div>
    </section>
  );
}

/** angebote – coloured cards with icon, title and short text (e.g. home page). */
export function OffersSection({ section: s }: Props) {
  if (s.offers.length === 0) return null;
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="mb-6 text-lg" />
      <ul className={cn("grid gap-5", gridCols(s.offers.length))}>
        {s.offers.map((o, i) => (
          <li key={i} className={cn(cardBase, toneBg(cycleTone(o.color_tone, i)), "p-6")}>
            <DbIcon name={o.icon} className="size-7 text-primary" />
            {o.title && <h3 className="mt-4 text-xl font-semibold text-foreground">{o.title}</h3>}
            <Markdown text={o.description} className="mt-2 leading-relaxed" />
          </li>
        ))}
      </ul>
    </section>
  );
}

/** öffnungszeiten – days, highlighted hours, notes, info pairs and a closing paragraph. */
export function OpeningHoursSection({ section: s }: Props) {
  const pairs = s.blocks.filter((b) => b.block_type === "info_pair");
  return (
    <section className={cn(cardBase, toneBg(s.color_tone), "h-full p-8")}>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="flex items-center gap-3 text-2xl md:text-3xl">
          <DbIcon name={s.icon} className="size-7 text-primary" />
          {s.heading}
        </SectionHeading>
      )}
      <div className="mt-5 space-y-3">
        {s.blocks.map((b, i) => {
          if (b.block_type === "info_pair") {
            if (b !== pairs[0]) return null;
            return (
              <dl key={i} className="grid gap-4 py-2 sm:grid-cols-2">
                {pairs.map((p, j) => (
                  <div key={j} className="rounded-2xl bg-card px-4 py-3">
                    <dt className="text-sm text-muted-foreground">{p.title}</dt>
                    <dd className="mt-1 font-medium text-foreground">{p.content}</dd>
                  </div>
                ))}
              </dl>
            );
          }
          if (b.block_type === "highlight")
            return (
              <p key={i} className="font-titel text-3xl font-medium text-foreground">
                {b.content}
              </p>
            );
          if (b.block_type === "label")
            return (
              <p key={i} className={cn(i === 0 ? "text-lg text-foreground" : "font-semibold text-blatt")}>
                {b.content}
              </p>
            );
          return <Markdown key={i} text={b.content} className="leading-relaxed" />;
        })}
      </div>
    </section>
  );
}

const DOT: Record<string, string> = {
  vanille: "bg-sonne",
  gelb: "bg-sonne",
  rosa: "bg-primary",
  hellblau: "bg-foreground",
  mint: "bg-blatt",
};

/** tagesablauf – one part of the day as a small timeline card. */
export function ScheduleSection({ section: s }: Props) {
  if (s.schedule.length === 0) return null;
  return (
    <section className={cn(cardBase, "h-full bg-card p-6")}>
      {s.heading && (
        <SectionHeading
          level={s.heading_level ?? "h2"}
          className={cn("inline-block rounded-full px-4 py-1 text-xl font-medium", toneBg(s.color_tone, "bg-banner"), s.color_tone === "vanille" && "bg-banner/50")}
        >
          {s.heading}
        </SectionHeading>
      )}
      <ol className="mt-5 space-y-5 border-l border-dashed border-border">
        {s.schedule.map((e, i) => (
          <li key={i} className="relative pl-6">
            <span
              className={cn("absolute -left-[6px] top-1.5 size-3 rounded-full", DOT[s.color_tone ?? ""] ?? "bg-primary")}
              aria-hidden="true"
            />
            <p className="font-titel text-lg font-medium text-foreground/80">{e.time_label}</p>
            <Markdown text={e.description} className="leading-relaxed" />
          </li>
        ))}
      </ol>
    </section>
  );
}

// Price colour per card tone, and box colour per child category (from `tariffs.child_category`).
const PRICE_TEXT: Record<string, string> = {
  rosa: "text-primary",
  hellblau: "text-foreground/75",
  mint: "text-blatt",
};
const CATEGORY_TONE: Record<string, string> = { saeugling: "rosa", kleinkind: "hellblau" };

/** tarif_tabelle (DB: price_card) – prices from the `tariffs` table. */
export function PriceCardSection({ section: s }: Props) {
  if (s.tariffs.length === 0) return null;
  const single = s.tariffs.length === 1 ? s.tariffs[0] : undefined;
  const plainCard = !s.color_tone || s.color_tone === "vanille" || s.color_tone === "cream";

  if (single) {
    return (
      <section className={cn(cardBase, toneBg(s.color_tone), "h-full p-8")}>
        <SectionHeading level={s.heading_level ?? "h2"} className="text-xl">
          {s.heading ?? single.label}
        </SectionHeading>
        <p className={cn("mt-2 font-titel text-4xl font-medium", PRICE_TEXT[s.color_tone ?? ""] ?? "text-foreground")}>
          {single.price_display}
        </p>
        {single.unit_label && <p className="text-sm text-muted-foreground">{single.unit_label}</p>}
        <Markdown text={single.description} className="mt-4 leading-relaxed" />
        <Markdown text={s.content} className="mt-4 leading-relaxed" />
      </section>
    );
  }

  return (
    <section className={cn(cardBase, toneBg(s.color_tone), "h-full p-8")}>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="text-2xl md:text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="mt-5 leading-relaxed" />
      {s.blocks.map((b, i) =>
        b.block_type === "subheading" ? (
          <h3 key={i} className="mt-6 font-bold text-foreground">
            {b.title ?? b.content}
          </h3>
        ) : (
          <p key={i} className="mt-1 text-sm text-muted-foreground">
            {b.content ?? b.title}
          </p>
        ),
      )}
      <dl className={cn("mt-4 grid gap-3", s.tariffs.length >= 3 ? "sm:grid-cols-3" : "sm:grid-cols-2")}>
        {s.tariffs.map((t, i) => (
          <div
            key={i}
            className={cn("rounded-2xl px-4 py-3", plainCard ? toneBg(CATEGORY_TONE[t.child_category]) : "bg-card")}
          >
            <dt className="text-sm text-muted-foreground">{t.label}</dt>
            <dd className="mt-1 font-titel text-xl font-medium text-foreground">{t.price_display}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

/** fragen_liste (DB: faq) – questions from the `faq` table as a fold-out list. */
export function FaqSection({ section: s }: Props) {
  if (s.faqs.length === 0) return null;
  return (
    <section className="mx-auto max-w-3xl">
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <Markdown text={s.content} className="mb-6 text-lg" />
      <Accordion type="single" collapsible className="space-y-3">
        {s.faqs.map((f, i) => (
          <AccordionItem key={i} value={`frage-${i}`} className={cn(cardBase, "border bg-card px-5")}>
            <AccordionTrigger className="py-5 text-lg font-semibold text-foreground">{f.question}</AccordionTrigger>
            <AccordionContent className="pb-5 text-base">
              <Markdown text={f.answer} className="leading-relaxed" />
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}

/** feiertage_liste – closing days of the year named in the heading (table `holidays`). */
export function HolidayListSection({ section: s }: Props) {
  if (s.holidays.length === 0) return null;
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-5 text-2xl">
          {s.heading}
        </SectionHeading>
      )}
      <ul className="space-y-3">
        {s.holidays.map((h, i) => (
          <li key={i} className={cn(cardBase, "flex items-center gap-4 bg-card px-5 py-4")}>
            <DbIcon name={s.icon} className="size-5 shrink-0 text-primary" />
            <div className="min-w-0 flex-1">
              <p className="text-lg text-foreground">{h.title}</p>
              <p className="text-sm text-muted-foreground">
                {formatLongDate(h.start_date)}
                {h.end_date !== h.start_date && ` – ${formatLongDate(h.end_date)}`}
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-rosa px-3 py-1 text-sm text-foreground">
              {h.description}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

/** team_raster – team members of one group with photo (or initials) and role. */
export function TeamSection({ section: s }: Props) {
  if (s.team.length === 0) return null;
  return (
    <section>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <ul className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-5">
        {s.team.map((m, i) => (
          <li key={i} className={cn(cardBase, "overflow-hidden bg-card")}>
            {m.photo ? (
              <img
                src={storageUrl(m.photo.bucket, m.photo.path)}
                alt={m.photo.alt ?? m.name}
                className="aspect-square w-full object-cover"
                loading="lazy"
              />
            ) : (
              <div
                className={cn("flex aspect-square items-center justify-center text-5xl text-foreground", toneBg(s.color_tone))}
                aria-hidden="true"
              >
                {m.initials}
              </div>
            )}
            <div className="p-4">
              <p className="text-lg text-foreground">{m.name}</p>
              <p className="text-sm text-muted-foreground">{m.role}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

/** zeitleiste – dated entries on a vertical line, optional signature below. */
export function TimelineSection({ section: s }: Props) {
  const entries = s.blocks.filter((b) => b.block_type === "timeline_entry");
  const signatures = s.blocks.filter((b) => b.block_type === "signature");
  if (entries.length === 0) return null;
  return (
    <section className="mx-auto max-w-3xl">
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-8 text-3xl">
          {s.heading}
        </SectionHeading>
      )}
      <ol className="space-y-12 border-l-2 border-dashed border-border">
        {entries.map((b, i) => (
          <li key={i} className="relative pl-10">
            <span
              className={cn("absolute -left-[9px] top-1 size-4 rounded-full", toneDot(b.color_tone))}
              aria-hidden="true"
            />
            {b.subtitle && (
              <p className="text-sm uppercase tracking-[0.2em] text-primary">{b.subtitle}</p>
            )}
            {b.title && <h2 className="mt-1 text-2xl font-bold text-foreground">{b.title}</h2>}
            <Markdown text={b.content} className="mt-4 space-y-4 leading-relaxed" />
          </li>
        ))}
      </ol>
      {signatures.map((b, i) => (
        <p key={i} className="mt-10 font-titel text-lg text-himmel">
          {b.content}
        </p>
      ))}
    </section>
  );
}

// Contact card type -> symbol (building block only; texts come from the database).
const CONTACT_ICONS: Record<string, typeof MapPin> = {
  contact_address: MapPin,
  contact_phone: Phone,
  contact_email: Mail,
};

/** kontakt_karten (DB: contact_cards) – address, phone and e-mail cards; values from `site_settings`. */
export function ContactCardsSection({ section: s }: Props) {
  const cards = s.blocks.filter((b) => b.title || b.content);
  return (
    <section className={cn("grid gap-6", gridCols(cards.length))}>
      {cards.map((c, i) => {
        const Icon = CONTACT_ICONS[c.block_type];
        return (
          <article key={i} className={cn(cardBase, toneBg(cycleTone(c.color_tone, i)), "p-8")}>
            {Icon && (
              <span className="mb-4 inline-flex size-11 items-center justify-center rounded-2xl bg-card text-primary">
                <Icon className="size-5" aria-hidden="true" />
              </span>
            )}
            {c.title && <h2 className="text-xl font-semibold text-foreground">{c.title}</h2>}
            <Markdown text={c.content} className="mt-2 leading-relaxed" />
            {c.button_url && (
              <div className="mt-3">
                <BlockLink block={c} />
              </div>
            )}
          </article>
        );
      })}
    </section>
  );
}

/** karte (DB: map) – map is only loaded after a click (privacy); address from `site_settings.karte_url`. */
export function MapSection({ section: s }: Props) {
  const [loaded, setLoaded] = useState(false);
  const consent = s.blocks.find((b) => b.block_type === "map_consent");
  const button = s.blocks.find((b) => b.block_type === "button");
  const embed = s.blocks.find((b) => b.block_type === "map_embed");
  const url = embed?.button_url && /^https:\/\//.test(embed.button_url) ? embed.button_url : null;
  if (!url) return null;
  return (
    <section className={cn(cardBase, "overflow-hidden bg-card")}>
      {loaded ? (
        <iframe
          src={url}
          title={embed?.title ?? ""}
          className="block h-[420px] w-full border-0"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      ) : (
        <div className="flex min-h-[320px] flex-col items-center justify-center gap-5 bg-hellblau/60 p-8 text-center">
          <MapPin className="size-10 text-primary" aria-hidden="true" />
          <Markdown text={consent?.content} className="max-w-xl text-muted-foreground" />
          <Button type="button" variant="cta" size="pill" onClick={() => setLoaded(true)}>
            {button?.button_text}
          </Button>
        </div>
      )}
    </section>
  );
}
