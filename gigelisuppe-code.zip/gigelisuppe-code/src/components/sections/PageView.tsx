import { useSuspenseQuery } from "@tanstack/react-query";
import type { ComponentType } from "react";
import {
  layoutQueryOptions,
  settingsQueryOptions,
  type Page,
  type Section,
} from "@/lib/content.functions";
import { fillPlaceholders } from "@/lib/text";
import { cn } from "@/lib/utils";
import {
  CardSection,
  CardsSection,
  ContactCardsSection,
  CtaSection,
  FaqSection,
  GallerySection,
  HeroSection,
  HolidayListSection,
  ImageCardsSection,
  InfoBoxSection,
  MapSection,
  OffersSection,
  OpeningHoursSection,
  PriceCardSection,
  QuoteSection,
  ScheduleSection,
  TagListSection,
  TeamSection,
  TimelineSection,
  TextSection,
} from "./sections";
import { FormSection } from "./FormSection";

/**
 * Section type (as stored in `page_sections.section_type`) -> building block.
 * Types without an entry are skipped silently; later steps add their blocks.
 */
const SECTION_COMPONENTS: Record<string, ComponentType<{ section: Section }>> = {
  hero: HeroSection, // hero
  legal_text: TextSection, // text
  image_with_cards: ImageCardsSection, // text_bild
  card: CardSection, // karten (einzeln)
  cards: CardsSection, // karten (Gruppe)
  value_cards: CardsSection, // karten (Werte)
  tag_list: TagListSection, // liste
  gallery: GallerySection, // galerie
  testimonials: QuoteSection, // zitat
  info_box: InfoBoxSection, // info_box
  cta: CtaSection, // aufruf
  offers: OffersSection, // karten (Angebote)
  opening_hours: OpeningHoursSection, // öffnungszeiten
  schedule: ScheduleSection, // tagesablauf (Zeitleiste)
  price_card: PriceCardSection, // tarif_tabelle (Preise aus `tariffs`)
  faq: FaqSection, // fragen_liste (Fragen aus `faq`)
  form: FormSection, // formular (Felder aus `form_fields`)
  team_group: TeamSection, // team_raster (Personen aus `team_members`)
  timeline: TimelineSection, // zeitleiste (Einträge aus `content_blocks`)
  contact_cards: ContactCardsSection, // kontakt_karten (Werte aus `site_settings`)
  map: MapSection, // karte (lädt erst nach Klick)
  holiday_list: HolidayListSection, // feiertage_liste (Jahr aus der Überschrift, Tage aus `holidays`)
};

// Blocks that sit side by side when they follow each other: section type -> grid columns.
const COMPACT: Record<string, string> = {
  card: "md:grid-cols-2",
  info_box: "md:grid-cols-2",
  opening_hours: "md:grid-cols-2",
  schedule: "md:grid-cols-2 lg:grid-cols-3",
};
const isMultiPrice = (s: Section) => s.section_type === "price_card" && s.tariffs.length > 1;
function groupKind(s: Section) {
  if (s.section_type === "schedule") return "trio";
  if (s.section_type === "price_card") return isMultiPrice(s) ? "aside" : "pair";
  if (s.section_type === "form" || s.section_type === "holiday_list") return "aside";
  return COMPACT[s.section_type] ? "pair" : null;
}

function fillSection(s: Section, vars: Record<string, string>): Section {
  const f = (t: string | null) => (t ? fillPlaceholders(t, vars) : t);
  return {
    ...s,
    heading: f(s.heading),
    content: f(s.content),
    blocks: s.blocks.map((b) => ({ ...b, title: f(b.title), content: f(b.content), button_url: f(b.button_url) })),
    offers: s.offers.map((o) => ({ ...o, description: f(o.description) ?? "" })),
    schedule: s.schedule.map((e) => ({ ...e, description: f(e.description) ?? "" })),
    faqs: s.faqs.map((q) => ({ ...q, answer: f(q.answer) ?? "" })),
  };
}

type Group = { kind: string | null; cols: string; sections: Section[] };

function groupSections(sections: Section[]): Group[] {
  const groups: Group[] = [];
  for (const s of sections) {
    const kind = groupKind(s);
    const last = groups.at(-1);
    // A wide price card, a form or a holiday list takes the cards that follow it into a side column.
    if (last?.kind === "aside" && (s.section_type === "card" || s.section_type === "info_box"))
      last.sections.push(s);
    else if (kind && kind !== "aside" && last?.kind === kind) last.sections.push(s);
    else groups.push({ kind, cols: COMPACT[s.section_type] ?? "md:grid-cols-2", sections: [s] });
  }
  return groups;
}

function renderSection(s: Section) {
  const C = SECTION_COMPONENTS[s.section_type]!;
  return <C key={s.section_key} section={s} />;
}

export function PageView({ page }: { page: Page }) {
  const { data: settings } = useSuspenseQuery(settingsQueryOptions());
  const { data: layout } = useSuspenseQuery(layoutQueryOptions());

  const known = page.sections
    .filter((s) => SECTION_COMPONENTS[s.section_type])
    .map((s) => fillSection(s, settings));
  const heroes = known.filter((s) => s.section_type === "hero");
  const body = known.filter((s) => s.section_type !== "hero");
  const cta = page.show_cta_section
    ? Object.values(layout.sections).find((s) => s.section_type === "cta")
    : undefined;

  return (
    <>
      {heroes.map((s) => (
        <HeroSection key={s.section_key} section={s} />
      ))}
      <div className="mx-auto max-w-6xl space-y-14 px-5 py-10">
        {groupSections(body).map((g) =>
          g.kind === "aside" && g.sections.length > 1 ? (
            <div key={g.sections[0]?.section_key} className="grid items-stretch gap-6 lg:grid-cols-[2fr_1fr]">
              {renderSection(g.sections[0]!)}
              <div className="flex flex-col gap-6">{g.sections.slice(1).map(renderSection)}</div>
            </div>
          ) : g.kind && g.sections.length > 1 ? (
            <div key={g.sections[0]?.section_key} className={cn("grid items-stretch gap-6", g.cols)}>
              {g.sections.map((s) => {
                const C = SECTION_COMPONENTS[s.section_type]!;
                return <C key={s.section_key} section={s} />;
              })}
            </div>
          ) : (
            g.sections.map((s) => {
              const C = SECTION_COMPONENTS[s.section_type]!;
              return <C key={s.section_key} section={s} />;
            })
          ),
        )}
        {cta && <CtaSection section={fillSection(cta, settings)} headingOverride={page.cta_heading_override} />}
      </div>
    </>
  );
}
