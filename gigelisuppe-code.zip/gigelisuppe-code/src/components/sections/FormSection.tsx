import { useServerFn } from "@tanstack/react-start";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { checkAnmeldung } from "@/lib/anmeldung";
import { submitAnmeldung } from "@/lib/anmeldung.functions";
import type { FormField, Section } from "@/lib/content.functions";
import { checkKontakt } from "@/lib/kontakt";
import { submitKontakt } from "@/lib/kontakt.functions";
import { cn } from "@/lib/utils";
import { Markdown, SectionHeading, cardBase, toneBg } from "./shared";

// form_key (from `form_fields`) -> browser check of that form.
const CHECKS: Record<string, (raw: unknown) => { ok: true } | { ok: false; invalid: string[] }> = {
  anmeldung: checkAnmeldung,
  kontakt: checkKontakt,
};

type Status = "idle" | "sending" | "done" | "invalid" | "failed";

const inputClass =
  "w-full rounded-2xl border border-border bg-background px-4 py-3 text-base text-foreground shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring aria-[invalid=true]:border-destructive";

/** formular (DB: form) – registration or contact form (by `form_key`); fields, labels and messages from the database. */
export function FormSection({ section: s }: { section: Section }) {
  const sendAnmeldung = useServerFn(submitAnmeldung);
  const sendKontakt = useServerFn(submitKontakt);
  const [status, setStatus] = useState<Status>("idle");
  const [invalid, setInvalid] = useState<string[]>([]);

  const formKey = s.fields[0]?.form_key ?? "";
  const checkForm = CHECKS[formKey];
  const send = formKey === "kontakt" ? sendKontakt : sendAnmeldung;
  if (!checkForm) return null;

  const text = (key: string) => s.blocks.find((b) => b.block_key === key);
  const button = s.blocks.find((b) => b.block_type === "form_button");
  const note = s.blocks.find((b) => b.block_type === "form_note");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const values = Object.fromEntries(new FormData(form).entries());
    const check = checkForm!(values);
    if (!check.ok) {
      setInvalid(check.invalid);
      setStatus("invalid");
      form.querySelector<HTMLElement>(`[name="${check.invalid[0]}"]`)?.focus();
      return;
    }
    setInvalid([]);
    setStatus("sending");
    try {
      const result = await send({ data: values });
      if (result.status === "ok") {
        form.reset();
        setStatus("done");
      } else if (result.status === "invalid") {
        setInvalid(result.invalid);
        setStatus("invalid");
      } else setStatus("failed");
    } catch {
      setStatus("failed");
    }
  }

  if (status === "done") {
    return (
      <section className={cn(cardBase, toneBg(s.color_tone), "p-8 md:p-10")} role="status">
        <CheckCircle2 className="size-10 text-blatt" aria-hidden="true" />
        <Markdown text={text("erfolg")?.content} className="mt-4 text-lg" />
      </section>
    );
  }

  return (
    <section className={cn(cardBase, toneBg(s.color_tone), "p-8 md:p-10")}>
      {s.heading && (
        <SectionHeading level={s.heading_level} className="mb-6 text-2xl">
          {s.heading}
        </SectionHeading>
      )}
      <form onSubmit={onSubmit} noValidate className="grid gap-x-5 gap-y-5 sm:grid-cols-2">
        {s.fields.map((f) => (
          <Field key={f.field_name} field={f} error={invalid.includes(f.field_name)} />
        ))}
        {/* Trap field for bots – hidden from people and screen readers. */}
        <input type="text" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />

        {(status === "invalid" || status === "failed") && (
          <div role="alert" className="rounded-2xl bg-rosa px-4 py-3 text-foreground sm:col-span-2">
            <Markdown text={text(status === "invalid" ? "fehler_angaben" : "fehler_senden")?.content} />
          </div>
        )}

        <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
          <Button type="submit" variant="cta" size="pill" disabled={status === "sending"}>
            {status === "sending" ? text("wird_gesendet")?.content : button?.button_text}
            {status !== "sending" && <ArrowRight aria-hidden="true" />}
          </Button>
          {note?.content && <span className="text-sm text-muted-foreground">{note.content}</span>}
        </div>
      </form>
    </section>
  );
}

function Field({ field: f, error }: { field: FormField; error: boolean }) {
  const id = `feld-${f.field_name}`;
  const common = {
    id,
    name: f.field_name,
    required: f.is_required,
    placeholder: f.placeholder ?? undefined,
    autoComplete: f.autocomplete ?? undefined,
    maxLength: f.max_length ?? undefined,
    minLength: f.min_length ?? undefined,
    "aria-invalid": error || undefined,
    "aria-describedby": error ? `${id}-fehler` : undefined,
    className: inputClass,
  };
  return (
    <div className={cn("flex flex-col gap-1.5", f.full_width && "sm:col-span-2")}>
      <label htmlFor={id} className="text-sm font-medium text-foreground">
        {f.label}
        {f.is_required && <span className="text-primary"> *</span>}
      </label>
      {f.field_type === "textarea" ? (
        <textarea {...common} rows={f.rows ?? 3} />
      ) : (
        <input {...common} type={f.field_type} />
      )}
      {error && f.validation_message && (
        <p id={`${id}-fehler`} className="text-sm text-destructive">
          {f.validation_message}
        </p>
      )}
    </div>
  );
}
