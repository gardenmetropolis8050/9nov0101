import { useRouter, type ErrorComponentProps } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function PageNotFound() {
  return (
    <div className="mx-auto max-w-3xl px-5 py-24 text-center">
      <h1 className="text-5xl font-bold text-foreground">404</h1>
      <p className="mt-3 text-muted-foreground">Diese Seite wurde nicht gefunden.</p>
    </div>
  );
}

export function PageError({ error, reset }: ErrorComponentProps) {
  const router = useRouter();
  return (
    <div role="alert" className="mx-auto max-w-md px-5 py-24 text-center">
      <p className="text-foreground">
        {error instanceof Error ? error.message : "Die Inhalte konnten nicht geladen werden."}
      </p>
      <Button
        variant="cta"
        size="pill"
        className="mt-6"
        onClick={() => {
          router.invalidate();
          reset();
        }}
      >
        Nochmals versuchen
      </Button>
    </div>
  );
}
