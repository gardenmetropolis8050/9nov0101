import {
  ArrowRight,
  CalendarDays,
  Check,
  Clock,
  ExternalLink,
  Heart,
  Leaf,
  Mail,
  MapPin,
  Phone,
  Quote,
  Sparkles,
  Star,
  Sun,
  type LucideIcon,
} from "lucide-react";
import ReactMarkdown, { defaultUrlTransform } from "react-markdown";
import remarkBreaks from "remark-breaks";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { SmartLink } from "@/components/site/SmartLink";
import type { Block } from "@/lib/content.functions";
import { cn } from "@/lib/utils";

// Colour names used in the database -> theme token classes (static strings for Tailwind).
const TONE_BG: Record<string, string> = {
  rosa: "bg-rosa",
  hellblau: "bg-hellblau",
  mint: "bg-mint",
  vanille: "bg-card",
  cream: "bg-card",
  gelb: "bg-sonne/50",
  "sunny-40": "bg-sonne/50",
};
const TONE_VAR: Record<string, string> = {
  rosa: "var(--rosa)",
  hellblau: "var(--hellblau)",
  mint: "var(--mint)",
  vanille: "var(--banner)",
  gelb: "var(--sonne)",
};
// Small accent dots (e.g. timeline): strong variant of the tone.
const TONE_DOT: Record<string, string> = {
  sunny: "bg-sonne",
  gelb: "bg-sonne",
  rose: "bg-primary",
  rosa: "bg-primary",
  sky: "bg-himmel",
  hellblau: "bg-himmel",
  mint: "bg-blatt",
};
export function toneDot(tone: string | null | undefined) {
  return (tone && TONE_DOT[tone]) || "bg-primary";
}
const TONE_CYCLE = ["hellblau", "mint", "rosa", "vanille"];

export function toneBg(tone: string | null | undefined, fallback = "bg-card") {
  return (tone && TONE_BG[tone]) || fallback;
}
export function toneVar(tone: string | null | undefined) {
  return (tone && TONE_VAR[tone]) || undefined;
}
/** Tone for item i: its own colour, otherwise a gentle rotation. */
export function cycleTone(tone: string | null | undefined, i: number) {
  return tone ?? TONE_CYCLE[i % TONE_CYCLE.length];
}

const ICONS: Record<string, LucideIcon> = {
  "arrow-right": ArrowRight,
  "calendar-days": CalendarDays,
  check: Check,
  clock: Clock,
  heart: Heart,
  leaf: Leaf,
  mail: Mail,
  "map-pin": MapPin,
  phone: Phone,
  quote: Quote,
  sparkles: Sparkles,
  star: Star,
  sun: Sun,
};
export function DbIcon({ name, className }: { name: string | null | undefined; className?: string }) {
  const Icon = name ? ICONS[name] : undefined;
  return Icon ? <Icon className={className} aria-hidden="true" /> : null;
}

// Allow phone links (tel:) on top of react-markdown's safe defaults (http, https, mailto, …).
const urlTransform = (url: string) => (/^tel:\+?[\d\s()/-]+$/i.test(url) ? url : defaultUrlTransform(url));

/** Markdown from the database. Raw HTML is dropped; unsafe link schemes are removed by the parser. */
export function Markdown({ text, className }: { text: string | null | undefined; className?: string }) {
  if (!text) return null;
  return (
    <div className={cn("md", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkBreaks]}
        skipHtml
        urlTransform={urlTransform}
        components={{
          a: ({ href, children }) => <SmartLink href={href ?? null}>{children}</SmartLink>,
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
}

/** Heading with the level stored in the database (default h2). */
export function SectionHeading({
  level,
  children,
  className,
}: {
  level: string | null | undefined;
  children: ReactNode;
  className?: string;
}) {
  const Tag = (["h1", "h2", "h3", "h4"].includes(level ?? "") ? level : "h2") as "h2";
  return <Tag className={cn("font-bold text-foreground", className)}>{children}</Tag>;
}

export function BlockButtons({ blocks, className }: { blocks: Block[]; className?: string }) {
  const buttons = blocks.filter((b) => b.block_type === "button" && b.button_text && b.button_url);
  if (buttons.length === 0) return null;
  return (
    <div className={cn("flex flex-wrap gap-3", className)}>
      {buttons.map((b, i) => (
        <Button key={i} asChild variant={b.button_style === "outline" ? "soft" : "cta"} size="pill">
          <SmartLink href={b.button_url} newTab={b.link_target === "_blank"}>
            {b.button_text}
            <DbIcon name={b.icon} />
          </SmartLink>
        </Button>
      ))}
    </div>
  );
}

export function BlockLink({ block }: { block: Block }) {
  if (!block.button_url) return null;
  const external = /^https?:/.test(block.button_url);
  return (
    <SmartLink
      href={block.button_url}
      newTab={external || block.link_target === "_blank"}
      className="inline-flex items-center gap-1.5 font-semibold text-primary underline underline-offset-4"
    >
      {block.button_text ?? block.button_url}
      {external && <ExternalLink className="size-4" aria-hidden="true" />}
    </SmartLink>
  );
}

export function CheckList({ items }: { items: string[] }) {
  if (items.length === 0) return null;
  return (
    <ul className="space-y-3">
      {items.map((t, i) => (
        <li key={i} className="flex gap-3">
          <Check className="mt-1 size-4 shrink-0 text-blatt" aria-hidden="true" />
          <Markdown text={t} />
        </li>
      ))}
    </ul>
  );
}

export const cardBase = "rounded-3xl border border-border/70 shadow-weich";
