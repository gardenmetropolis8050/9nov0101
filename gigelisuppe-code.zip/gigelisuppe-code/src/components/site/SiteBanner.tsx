import { useSuspenseQuery } from "@tanstack/react-query";
import { Sparkles } from "lucide-react";
import { layoutQueryOptions } from "@/lib/content.functions";
import { SmartLink } from "./SmartLink";

/** Yellow notice under the header, from `availability` rows marked as banner. */
export function SiteBanner() {
  const { data: layout } = useSuspenseQuery(layoutQueryOptions());
  const banner = layout.banner;
  if (!banner) return null;

  return (
    <div className="border-b border-border/60 bg-banner">
      <p className="mx-auto flex max-w-6xl flex-col items-center justify-center gap-x-3 gap-y-1 px-5 py-3 text-center text-foreground sm:flex-row">
        <Sparkles className="size-4 shrink-0 text-primary" aria-hidden="true" />
        <span>{banner.text}</span>
        {banner.linkLabel && banner.linkUrl && (
          <SmartLink
            href={banner.linkUrl}
            className="font-semibold text-primary underline decoration-2 underline-offset-4 hover:decoration-primary/40"
          >
            {banner.linkLabel}
          </SmartLink>
        )}
      </p>
    </div>
  );
}
