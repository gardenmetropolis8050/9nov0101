import { Fragment } from "react";
import { parseInlineLinks } from "@/lib/text";
import { SmartLink } from "./SmartLink";

/** Renders a short database text: line breaks plus markdown links. */
export function InlineText({ text, linkClassName }: { text: string; linkClassName?: string }) {
  const lines = text.split(/\r?\n/);
  return (
    <>
      {lines.map((line, i) => (
        <Fragment key={i}>
          {i > 0 && <br />}
          {parseInlineLinks(line).map((part, j) =>
            part.type === "link" ? (
              <SmartLink key={j} href={part.href} className={linkClassName}>
                {part.text}
              </SmartLink>
            ) : (
              <Fragment key={j}>{part.text}</Fragment>
            ),
          )}
        </Fragment>
      ))}
    </>
  );
}
