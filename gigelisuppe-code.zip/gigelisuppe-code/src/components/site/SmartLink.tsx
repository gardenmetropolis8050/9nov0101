import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

type Props = {
  href: string | null;
  children: ReactNode;
  className?: string | undefined;
  newTab?: boolean | undefined;
  onClick?: (() => void) | undefined;
  "aria-current"?: "page" | undefined;
};

/** Link for addresses from the database: internal pages use the router, everything else a plain <a>. */
export function SmartLink({ href, children, className, newTab, onClick, ...rest }: Props) {
  const target = newTab ? { target: "_blank", rel: "noopener noreferrer" } : {};
  if (!href) return <span className={className}>{children}</span>;
  if (href === "/") {
    return (
      <Link to="/" className={className} onClick={onClick} {...target} {...rest}>
        {children}
      </Link>
    );
  }
  const slug = /^\/([a-z0-9-]+)\/?$/.exec(href)?.[1];
  if (slug) {
    return (
      <Link to="/$slug" params={{ slug }} className={className} onClick={onClick} {...target} {...rest}>
        {children}
      </Link>
    );
  }
  return (
    <a href={href} className={className} onClick={onClick} {...target} {...rest}>
      {children}
    </a>
  );
}

/** True when the menu address points to the current page. */
export function isActiveHref(href: string | null, pathname: string): boolean {
  if (!href || !href.startsWith("/")) return false;
  const clean = (p: string) => (p.length > 1 ? p.replace(/\/$/, "") : p);
  return clean(href) === clean(pathname);
}
