import { useSuspenseQuery } from "@tanstack/react-query";
import { Clock, Mail, MapPin, Phone, type LucideIcon } from "lucide-react";
import { layoutQueryOptions, menusQueryOptions, settingsQueryOptions } from "@/lib/content.functions";
import { fillPlaceholders, storageUrl } from "@/lib/text";
import { InlineText } from "./InlineText";
import { SmartLink } from "./SmartLink";

const FOOTER_MENU = "footer";

const CONTACT_ICONS: Record<string, LucideIcon> = {
  contact_address: MapPin,
  contact_phone: Phone,
  contact_email: Mail,
};

export function SiteFooter() {
  const { data: settings } = useSuspenseQuery(settingsQueryOptions());
  const { data: menus } = useSuspenseQuery(menusQueryOptions());
  const { data: layout } = useSuspenseQuery(layoutQueryOptions());

  const s = layout.sections;
  const intro = s["footer-intro"];
  const kontakt = s["footer-kontakt"];
  const partner = s["footer-partner"];
  const copyright = s["footer-copyright"]?.blocks.find((b) => b.block_type === "copyright")?.content;
  const hours = layout.openingHours;
  const links = menus[FOOTER_MENU] ?? [];
  const fill = (t: string) => fillPlaceholders(t, settings);

  const introLogo = intro?.images.find((i) => i.usage === "logo");
  const logoSrc = introLogo ? storageUrl(introLogo.bucket, introLogo.path) : settings["logo_url"];
  const hourBlocks = hours?.blocks.filter((b) => b.block_type !== "paragraph" && b.content) ?? [];

  return (
    <footer className="mt-16 bg-hellblau text-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-2 lg:grid-cols-4">
        <div>
          {logoSrc && (
            <img
              src={logoSrc}
              alt={introLogo?.alt ?? settings["name"] ?? ""}
              className="h-14 w-auto"
              loading="lazy"
            />
          )}
          {intro?.content && <p className="mt-5 leading-relaxed">{fill(intro.content)}</p>}
        </div>

        {kontakt && (
          <div>
            {kontakt.heading && <h2 className="text-xl font-semibold">{kontakt.heading}</h2>}
            <ul className="mt-4 space-y-3">
              {kontakt.blocks.map((b, i) => {
                const Icon = CONTACT_ICONS[b.block_type];
                if (!b.content) return null;
                return (
                  <li key={i} className="flex gap-3">
                    {Icon && <Icon className="mt-1 size-4 shrink-0 text-primary" aria-hidden="true" />}
                    <span>
                      <InlineText text={fill(b.content)} linkClassName="hover:text-primary" />
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        )}

        {hours && hourBlocks.length > 0 && (
          <div>
            {hours.heading && <h2 className="text-xl font-semibold">{hours.heading}</h2>}
            <ul className="mt-4 space-y-2">
              {hourBlocks.map((b, i) => (
                <li key={i} className="flex gap-3">
                  {i === 0 ? (
                    <Clock className="mt-1 size-4 shrink-0 text-primary" aria-hidden="true" />
                  ) : (
                    <span className="size-4 shrink-0" aria-hidden="true" />
                  )}
                  <span className={b.block_type === "highlight" ? "font-semibold" : undefined}>
                    {b.title ? `${b.title}: ` : ""}
                    {fill(b.content ?? "")}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {partner && partner.images.length > 0 && (
          <div>
            {partner.heading && <h2 className="text-xl font-semibold">{partner.heading}</h2>}
            <ul className="mt-4 flex flex-wrap gap-4">
              {partner.images.map((img, i) => {
                const image = (
                  <img
                    src={storageUrl(img.bucket, img.path)}
                    alt={img.alt ?? ""}
                    className="h-12 w-auto max-w-full object-contain"
                    loading="lazy"
                  />
                );
                return (
                  <li key={i} className="rounded-xl bg-card p-1.5 shadow-weich">
                    {img.link ? <SmartLink href={img.link} newTab>{image}</SmartLink> : image}
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>

      <div className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-5 text-sm sm:flex-row">
          {copyright && <p>{fill(copyright)}</p>}
          {links.length > 0 && (
            <ul className="flex flex-wrap gap-4">
              {links.map((l) => (
                <li key={l.id}>
                  <SmartLink href={l.href} newTab={l.newTab} className="hover:text-primary">
                    {l.label}
                  </SmartLink>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </footer>
  );
}
