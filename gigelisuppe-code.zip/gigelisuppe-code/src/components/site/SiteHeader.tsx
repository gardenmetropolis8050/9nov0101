import { useSuspenseQuery } from "@tanstack/react-query";
import { useRouterState } from "@tanstack/react-router";
import { ChevronDown, Menu, X } from "lucide-react";
import { useEffect, useState, type KeyboardEvent } from "react";
import { layoutQueryOptions, menusQueryOptions, settingsQueryOptions } from "@/lib/content.functions";
import type { MenuItem } from "@/lib/menu";
import { cn } from "@/lib/utils";
import { isActiveHref, SmartLink } from "./SmartLink";

const MAIN_MENU = "hauptmenue";

function isItemActive(item: MenuItem, pathname: string): boolean {
  return isActiveHref(item.href, pathname) || item.children.some((c) => isItemActive(c, pathname));
}

export function SiteHeader() {
  const { data: settings } = useSuspenseQuery(settingsQueryOptions());
  const { data: menus } = useSuspenseQuery(menusQueryOptions());
  const { data: layout } = useSuspenseQuery(layoutQueryOptions());
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  const items = menus[MAIN_MENU] ?? [];
  const header = layout.sections["header"];
  const text = (key: string) => header?.blocks.find((b) => b.block_key === key)?.content ?? undefined;
  const logoUrl = settings["logo_url"];
  const name = settings["name"] ?? "";

  // Escape closes an open submenu for keyboard users.
  const onSubmenuKey = (e: KeyboardEvent<HTMLLIElement>) => {
    if (e.key === "Escape" && document.activeElement instanceof HTMLElement) document.activeElement.blur();
  };

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-6xl items-center justify-between gap-4 px-5">
        <SmartLink href="/" className="shrink-0" aria-current={pathname === "/" ? "page" : undefined}>
          {logoUrl ? (
            <img src={logoUrl} alt={name} className="h-12 w-auto md:h-14" />
          ) : (
            <span className="font-titel text-2xl text-foreground">{name}</span>
          )}
        </SmartLink>

        <nav aria-label={text("nav_desktop")} className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {items.map((item) => {
              const active = isItemActive(item, pathname);
              return (
                <li key={item.id} className="group relative" onKeyDown={onSubmenuKey}>
                  <SmartLink
                    href={item.href}
                    newTab={item.newTab}
                    aria-current={isActiveHref(item.href, pathname) ? "page" : undefined}
                    className={cn(
                      "flex items-center gap-1 rounded-full px-4 py-2 font-titel text-[1.05rem] transition-colors hover:bg-secondary focus-visible:bg-secondary focus-visible:outline-none",
                      active ? "text-primary" : "text-foreground",
                    )}
                  >
                    {item.label}
                    {item.children.length > 0 && <ChevronDown className="size-4" aria-hidden="true" />}
                  </SmartLink>
                  {item.children.length > 0 && (
                    <div className="invisible absolute left-1/2 top-full z-50 w-64 -translate-x-1/2 pt-2 opacity-0 transition-all group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                      <ul className="rounded-2xl border border-border/70 bg-card p-2 shadow-weich">
                        {item.children.map((child) => {
                          const childActive = isActiveHref(child.href, pathname);
                          return (
                            <li key={child.id}>
                              <SmartLink
                                href={child.href}
                                newTab={child.newTab}
                                aria-current={childActive ? "page" : undefined}
                                className={cn(
                                  "block rounded-xl px-4 py-2 hover:bg-hellblau focus-visible:bg-hellblau focus-visible:outline-none",
                                  childActive ? "text-primary" : "text-foreground",
                                )}
                              >
                                {child.label}
                              </SmartLink>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full text-foreground hover:bg-secondary lg:hidden"
          aria-expanded={open}
          aria-controls="mobiles-menue"
          aria-label={open ? text("menu_close") : text("menu_open")}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-6" aria-hidden="true" /> : <Menu className="size-6" aria-hidden="true" />}
        </button>
      </div>

      {open && (
        <nav
          id="mobiles-menue"
          aria-label={text("nav_mobile")}
          className="max-h-[calc(100vh-5rem)] overflow-y-auto border-t border-border/60 bg-background lg:hidden"
        >
          <ul className="mx-auto max-w-6xl space-y-1 px-5 py-4">
            {items.map((item) => {
              const active = isItemActive(item, pathname);
              return (
                <li key={item.id}>
                  <SmartLink
                    href={item.href}
                    newTab={item.newTab}
                    aria-current={isActiveHref(item.href, pathname) ? "page" : undefined}
                    className={cn(
                      "block rounded-xl px-4 py-3 font-titel text-lg hover:bg-secondary",
                      active ? "text-primary" : "text-foreground",
                    )}
                  >
                    {item.label}
                  </SmartLink>
                  {item.children.length > 0 && (
                    <ul className="mb-2 ml-4 border-l-2 border-border pl-2">
                      {item.children.map((child) => {
                        const childActive = isActiveHref(child.href, pathname);
                        return (
                          <li key={child.id}>
                            <SmartLink
                              href={child.href}
                              newTab={child.newTab}
                              aria-current={childActive ? "page" : undefined}
                              className={cn(
                                "block rounded-xl px-4 py-2 hover:bg-hellblau",
                                childActive ? "text-primary" : "text-foreground",
                              )}
                            >
                              {child.label}
                            </SmartLink>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </header>
  );
}
