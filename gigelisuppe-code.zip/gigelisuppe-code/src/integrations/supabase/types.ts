export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      anmeldungen: {
        Row: {
          adresse: string
          created_at: string
          eintritt: string
          eltern: string | null
          email: string
          geburtstag: string
          id: string
          kind: string
          sonstiges: string | null
          tage: string
          telefon: string
        }
        Insert: {
          adresse: string
          created_at?: string
          eintritt: string
          eltern?: string | null
          email: string
          geburtstag: string
          id?: string
          kind: string
          sonstiges?: string | null
          tage: string
          telefon: string
        }
        Update: {
          adresse?: string
          created_at?: string
          eintritt?: string
          eltern?: string | null
          email?: string
          geburtstag?: string
          id?: string
          kind?: string
          sonstiges?: string | null
          tage?: string
          telefon?: string
        }
        Relationships: []
      }
      availability: {
        Row: {
          age_group: string | null
          available_from: string
          available_places: number | null
          available_until: string | null
          banner_link_label: string | null
          banner_link_url: string | null
          created_at: string
          description: string
          id: number
          is_visible: boolean
          notes: string | null
          show_as_banner: boolean
          updated_at: string
        }
        Insert: {
          age_group?: string | null
          available_from: string
          available_places?: number | null
          available_until?: string | null
          banner_link_label?: string | null
          banner_link_url?: string | null
          created_at?: string
          description: string
          id?: number
          is_visible?: boolean
          notes?: string | null
          show_as_banner?: boolean
          updated_at?: string
        }
        Update: {
          age_group?: string | null
          available_from?: string
          available_places?: number | null
          available_until?: string | null
          banner_link_label?: string | null
          banner_link_url?: string | null
          created_at?: string
          description?: string
          id?: number
          is_visible?: boolean
          notes?: string | null
          show_as_banner?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      content_blocks: {
        Row: {
          block_key: string | null
          block_type: string
          button_style: string | null
          button_text: string | null
          button_url: string | null
          color_tone: string | null
          content: string | null
          created_at: string
          icon: string | null
          id: number
          is_visible: boolean
          link_target: string
          section_id: number
          sort_order: number
          subtitle: string | null
          title: string | null
          updated_at: string
        }
        Insert: {
          block_key?: string | null
          block_type: string
          button_style?: string | null
          button_text?: string | null
          button_url?: string | null
          color_tone?: string | null
          content?: string | null
          created_at?: string
          icon?: string | null
          id?: number
          is_visible?: boolean
          link_target?: string
          section_id: number
          sort_order?: number
          subtitle?: string | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          block_key?: string | null
          block_type?: string
          button_style?: string | null
          button_text?: string | null
          button_url?: string | null
          color_tone?: string | null
          content?: string | null
          created_at?: string
          icon?: string | null
          id?: number
          is_visible?: boolean
          link_target?: string
          section_id?: number
          sort_order?: number
          subtitle?: string | null
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_blocks_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      faq: {
        Row: {
          answer: string
          category: string
          created_at: string
          id: number
          is_visible: boolean
          question: string
          section_id: number | null
          sort_order: number
          updated_at: string
        }
        Insert: {
          answer: string
          category?: string
          created_at?: string
          id?: number
          is_visible?: boolean
          question: string
          section_id?: number | null
          sort_order?: number
          updated_at?: string
        }
        Update: {
          answer?: string
          category?: string
          created_at?: string
          id?: number
          is_visible?: boolean
          question?: string
          section_id?: number | null
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "faq_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      form_fields: {
        Row: {
          autocomplete: string | null
          created_at: string
          field_name: string
          field_type: string
          form_key: string
          full_width: boolean
          id: number
          is_required: boolean
          is_visible: boolean
          label: string
          max_length: number | null
          min_length: number | null
          placeholder: string | null
          rows: number | null
          section_id: number
          sort_order: number
          updated_at: string
          validation_message: string | null
        }
        Insert: {
          autocomplete?: string | null
          created_at?: string
          field_name: string
          field_type: string
          form_key?: string
          full_width?: boolean
          id?: number
          is_required?: boolean
          is_visible?: boolean
          label: string
          max_length?: number | null
          min_length?: number | null
          placeholder?: string | null
          rows?: number | null
          section_id: number
          sort_order?: number
          updated_at?: string
          validation_message?: string | null
        }
        Update: {
          autocomplete?: string | null
          created_at?: string
          field_name?: string
          field_type?: string
          form_key?: string
          full_width?: boolean
          id?: number
          is_required?: boolean
          is_visible?: boolean
          label?: string
          max_length?: number | null
          min_length?: number | null
          placeholder?: string | null
          rows?: number | null
          section_id?: number
          sort_order?: number
          updated_at?: string
          validation_message?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "form_fields_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      holidays: {
        Row: {
          closed_from: string | null
          closure_type: string
          created_at: string
          description: string
          display_year: number
          end_date: string
          id: number
          is_visible: boolean
          sort_order: number
          start_date: string
          title: string
          updated_at: string
        }
        Insert: {
          closed_from?: string | null
          closure_type?: string
          created_at?: string
          description: string
          display_year: number
          end_date: string
          id?: number
          is_visible?: boolean
          sort_order?: number
          start_date: string
          title: string
          updated_at?: string
        }
        Update: {
          closed_from?: string | null
          closure_type?: string
          created_at?: string
          description?: string
          display_year?: number
          end_date?: string
          id?: number
          is_visible?: boolean
          sort_order?: number
          start_date?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      images: {
        Row: {
          alt_text: string | null
          category: string
          created_at: string
          description: string
          file_size_bytes: number | null
          filename: string
          format: string
          height: number | null
          id: number
          image_code: string
          is_decorative: boolean
          mime_type: string
          notes: string | null
          original_filename: string
          original_url: string | null
          storage_bucket: string
          storage_path: string
          updated_at: string
          visual_duplicate_of: number | null
          width: number | null
        }
        Insert: {
          alt_text?: string | null
          category: string
          created_at?: string
          description: string
          file_size_bytes?: number | null
          filename: string
          format: string
          height?: number | null
          id?: number
          image_code: string
          is_decorative?: boolean
          mime_type: string
          notes?: string | null
          original_filename: string
          original_url?: string | null
          storage_bucket?: string
          storage_path: string
          updated_at?: string
          visual_duplicate_of?: number | null
          width?: number | null
        }
        Update: {
          alt_text?: string | null
          category?: string
          created_at?: string
          description?: string
          file_size_bytes?: number | null
          filename?: string
          format?: string
          height?: number | null
          id?: number
          image_code?: string
          is_decorative?: boolean
          mime_type?: string
          notes?: string | null
          original_filename?: string
          original_url?: string | null
          storage_bucket?: string
          storage_path?: string
          updated_at?: string
          visual_duplicate_of?: number | null
          width?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "images_visual_duplicate_of_fkey"
            columns: ["visual_duplicate_of"]
            isOneToOne: false
            referencedRelation: "images"
            referencedColumns: ["id"]
          },
        ]
      }
      kontakt_nachrichten: {
        Row: {
          created_at: string
          email: string
          id: string
          nachricht: string
          name: string
          telefon: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          nachricht: string
          name: string
          telefon?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          nachricht?: string
          name?: string
          telefon?: string | null
        }
        Relationships: []
      }
      navigation: {
        Row: {
          created_at: string
          id: number
          is_visible: boolean
          label: string
          menu: string
          open_in_new_tab: boolean
          page_id: number | null
          parent_id: number | null
          sort_order: number
          updated_at: string
          url: string | null
        }
        Insert: {
          created_at?: string
          id?: number
          is_visible?: boolean
          label: string
          menu?: string
          open_in_new_tab?: boolean
          page_id?: number | null
          parent_id?: number | null
          sort_order?: number
          updated_at?: string
          url?: string | null
        }
        Update: {
          created_at?: string
          id?: number
          is_visible?: boolean
          label?: string
          menu?: string
          open_in_new_tab?: boolean
          page_id?: number | null
          parent_id?: number | null
          sort_order?: number
          updated_at?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "navigation_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "navigation_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "navigation"
            referencedColumns: ["id"]
          },
        ]
      }
      offers: {
        Row: {
          color_tone: string | null
          created_at: string
          description: string
          icon: string | null
          id: number
          is_visible: boolean
          section_id: number
          sort_order: number
          title: string | null
          updated_at: string
        }
        Insert: {
          color_tone?: string | null
          created_at?: string
          description: string
          icon?: string | null
          id?: number
          is_visible?: boolean
          section_id: number
          sort_order?: number
          title?: string | null
          updated_at?: string
        }
        Update: {
          color_tone?: string | null
          created_at?: string
          description?: string
          icon?: string | null
          id?: number
          is_visible?: boolean
          section_id?: number
          sort_order?: number
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "offers_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      page_sections: {
        Row: {
          color_tone: string | null
          content: string | null
          created_at: string
          eyebrow: string | null
          heading: string | null
          heading_level: string | null
          icon: string | null
          id: number
          is_visible: boolean
          page_id: number
          section_key: string
          section_name: string
          section_type: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          color_tone?: string | null
          content?: string | null
          created_at?: string
          eyebrow?: string | null
          heading?: string | null
          heading_level?: string | null
          icon?: string | null
          id?: number
          is_visible?: boolean
          page_id: number
          section_key: string
          section_name: string
          section_type: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          color_tone?: string | null
          content?: string | null
          created_at?: string
          eyebrow?: string | null
          heading?: string | null
          heading_level?: string | null
          icon?: string | null
          id?: number
          is_visible?: boolean
          page_id?: number
          section_key?: string
          section_name?: string
          section_type?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "page_sections_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "pages"
            referencedColumns: ["id"]
          },
        ]
      }
      pages: {
        Row: {
          created_at: string
          cta_heading_override: string | null
          description: string | null
          id: number
          is_published: boolean
          meta_description: string | null
          meta_title: string | null
          og_description: string | null
          og_title: string | null
          page_type: string
          path: string | null
          show_cta_section: boolean
          slug: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          cta_heading_override?: string | null
          description?: string | null
          id?: number
          is_published?: boolean
          meta_description?: string | null
          meta_title?: string | null
          og_description?: string | null
          og_title?: string | null
          page_type?: string
          path?: string | null
          show_cta_section?: boolean
          slug: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          cta_heading_override?: string | null
          description?: string | null
          id?: number
          is_published?: boolean
          meta_description?: string | null
          meta_title?: string | null
          og_description?: string | null
          og_title?: string | null
          page_type?: string
          path?: string | null
          show_cta_section?: boolean
          slug?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      schedule_entries: {
        Row: {
          created_at: string
          description: string
          end_time: string | null
          id: number
          is_visible: boolean
          section_id: number
          sort_order: number
          start_time: string
          time_label: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description: string
          end_time?: string | null
          id?: number
          is_visible?: boolean
          section_id: number
          sort_order?: number
          start_time: string
          time_label: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string
          end_time?: string | null
          id?: number
          is_visible?: boolean
          section_id?: number
          sort_order?: number
          start_time?: string
          time_label?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "schedule_entries_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      section_images: {
        Row: {
          caption: string | null
          created_at: string
          id: number
          image_id: number
          is_visible: boolean
          link_url: string | null
          section_id: number
          sort_order: number
          updated_at: string
          usage_type: string
        }
        Insert: {
          caption?: string | null
          created_at?: string
          id?: number
          image_id: number
          is_visible?: boolean
          link_url?: string | null
          section_id: number
          sort_order?: number
          updated_at?: string
          usage_type: string
        }
        Update: {
          caption?: string | null
          created_at?: string
          id?: number
          image_id?: number
          is_visible?: boolean
          link_url?: string | null
          section_id?: number
          sort_order?: number
          updated_at?: string
          usage_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "section_images_image_id_fkey"
            columns: ["image_id"]
            isOneToOne: false
            referencedRelation: "images"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "section_images_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      site_settings: {
        Row: {
          created_at: string
          is_public: boolean
          key: string
          label: string
          setting_group: string
          sort_order: number
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          is_public?: boolean
          key: string
          label: string
          setting_group?: string
          sort_order?: number
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          is_public?: boolean
          key?: string
          label?: string
          setting_group?: string
          sort_order?: number
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      tariffs: {
        Row: {
          child_category: string
          created_at: string
          description: string | null
          id: number
          is_visible: boolean
          label: string
          price_chf: number | null
          price_display: string
          price_kleinkind_chf: number | null
          price_saeugling_chf: number | null
          section_id: number
          sort_order: number
          tariff_key: string
          unit_label: string | null
          updated_at: string
        }
        Insert: {
          child_category: string
          created_at?: string
          description?: string | null
          id?: number
          is_visible?: boolean
          label: string
          price_chf?: number | null
          price_display: string
          price_kleinkind_chf?: number | null
          price_saeugling_chf?: number | null
          section_id: number
          sort_order?: number
          tariff_key: string
          unit_label?: string | null
          updated_at?: string
        }
        Update: {
          child_category?: string
          created_at?: string
          description?: string | null
          id?: number
          is_visible?: boolean
          label?: string
          price_chf?: number | null
          price_display?: string
          price_kleinkind_chf?: number | null
          price_saeugling_chf?: number | null
          section_id?: number
          sort_order?: number
          tariff_key?: string
          unit_label?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tariffs_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      team_members: {
        Row: {
          created_at: string
          id: number
          image_id: number | null
          initials: string | null
          is_visible: boolean
          name: string
          role: string
          section_id: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: number
          image_id?: number | null
          initials?: string | null
          is_visible?: boolean
          name: string
          role: string
          section_id: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: number
          image_id?: number | null
          initials?: string | null
          is_visible?: boolean
          name?: string
          role?: string
          section_id?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_members_image_id_fkey"
            columns: ["image_id"]
            isOneToOne: false
            referencedRelation: "images"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_members_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      testimonials: {
        Row: {
          author: string | null
          body: string
          color_tone: string | null
          created_at: string
          id: number
          is_visible: boolean
          section_id: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          author?: string | null
          body: string
          color_tone?: string | null
          created_at?: string
          id?: number
          is_visible?: boolean
          section_id: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          author?: string | null
          body?: string
          color_tone?: string | null
          created_at?: string
          id?: number
          is_visible?: boolean
          section_id?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "testimonials_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "page_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      theme: {
        Row: {
          created_at: string
          farbe_akzent_blau: string
          farbe_akzent_gelb: string
          farbe_akzent_gruen: string
          farbe_akzent_mint: string
          farbe_akzent_rosa: string
          farbe_banner: string
          farbe_haupt: string
          farbe_haupt_text: string
          farbe_hintergrund: string
          farbe_karte: string
          farbe_rand: string
          farbe_text: string
          farbe_text_leise: string
          id: number
          rundung_px: number
          schatten_staerke: number
          schrift_text: string
          schrift_titel: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          farbe_akzent_blau: string
          farbe_akzent_gelb: string
          farbe_akzent_gruen: string
          farbe_akzent_mint: string
          farbe_akzent_rosa: string
          farbe_banner: string
          farbe_haupt: string
          farbe_haupt_text: string
          farbe_hintergrund: string
          farbe_karte: string
          farbe_rand: string
          farbe_text: string
          farbe_text_leise: string
          id?: number
          rundung_px?: number
          schatten_staerke?: number
          schrift_text: string
          schrift_titel: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          farbe_akzent_blau?: string
          farbe_akzent_gelb?: string
          farbe_akzent_gruen?: string
          farbe_akzent_mint?: string
          farbe_akzent_rosa?: string
          farbe_banner?: string
          farbe_haupt?: string
          farbe_haupt_text?: string
          farbe_hintergrund?: string
          farbe_karte?: string
          farbe_rand?: string
          farbe_text?: string
          farbe_text_leise?: string
          id?: number
          rundung_px?: number
          schatten_staerke?: number
          schrift_text?: string
          schrift_titel?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: number
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: number
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: number
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      v_bilder_verwendung: {
        Row: {
          alt_text: string | null
          bereich: string | null
          bildunterschrift: string | null
          category: string | null
          filename: string | null
          image_code: string | null
          seite: string | null
          seitenname: string | null
          storage_path: string | null
          verwendung: string | null
        }
        Relationships: []
      }
      v_seiteninhalte: {
        Row: {
          bereich_nr: number | null
          bereich_ueberschrift: string | null
          block_type: string | null
          element_nr: number | null
          element_text: string | null
          element_titel: string | null
          link: string | null
          section_key: string | null
          section_type: string | null
          seite: string | null
          seite_nr: number | null
          seitenname: string | null
          sichtbar: boolean | null
        }
        Relationships: []
      }
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
      is_page_public: { Args: { _page_id: number }; Returns: boolean }
      is_section_public: { Args: { _section_id: number }; Returns: boolean }
    }
    Enums: {
      app_role: "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin"],
    },
  },
} as const
