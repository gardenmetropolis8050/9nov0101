import { useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { PageView } from "@/components/sections/PageView";
import { PageError, PageNotFound } from "@/components/sections/PageStates";
import { pageQueryOptions } from "@/lib/content.functions";
import { pageHead } from "@/lib/page-head";

const HOME_SLUG = "home";

export const Route = createFileRoute("/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(pageQueryOptions(HOME_SLUG)),
  head: ({ loaderData }) => pageHead(loaderData, "/"),
  component: HomePage,
  errorComponent: PageError,
  notFoundComponent: PageNotFound,
});

function HomePage() {
  const { data: page } = useSuspenseQuery(pageQueryOptions(HOME_SLUG));
  return <PageView page={page} />;
}
