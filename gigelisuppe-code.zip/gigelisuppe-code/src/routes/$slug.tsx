import { useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, notFound } from "@tanstack/react-router";
import { PageView } from "@/components/sections/PageView";
import { PageError, PageNotFound } from "@/components/sections/PageStates";
import { pageQueryOptions } from "@/lib/content.functions";
import { pageHead } from "@/lib/page-head";

// Every published page with a path like "/angebot" is reachable here; internal
// entries without a path (global parts, error texts) and "home" are not.
export const Route = createFileRoute("/$slug")({
  loader: async ({ params, context }) => {
    const page = await context.queryClient.ensureQueryData(pageQueryOptions(params.slug));
    if (page.path !== `/${params.slug}`) throw notFound();
    return page;
  },
  head: ({ loaderData, params }) => pageHead(loaderData, `/${params.slug}`),
  component: SlugPage,
  errorComponent: PageError,
  notFoundComponent: PageNotFound,
});

function SlugPage() {
  const { slug } = Route.useParams();
  const { data: page } = useSuspenseQuery(pageQueryOptions(slug));
  return <PageView page={page} />;
}
