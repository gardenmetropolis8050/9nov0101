<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- All content and design values come from Supabase; never hardcode texts, image URLs, phone numbers or color values in components — the code holds only building blocks and fallback defaults.
- Colors only via CSS variables (design tokens) that are set at runtime from the `theme` table — keeps the design editable by the customer without code changes.
- Every step updates `fortschritt.md` — it is the single progress tracker for the 20-step build.
- The `theme` row is read server-side in the root route loader (`src/lib/theme.functions.ts`) and injected as a `:root{}` style + Google Fonts links in `head()`; `src/lib/theme.ts` validates values and returns nothing on failure — first paint is correct and a DB outage falls back to the CSS defaults.
- The customer's Supabase already holds the content schema (`pages`, `site_settings`, `navigation`, `availability`, `page_sections`, `content_blocks`, `images`, ...). When a step file names a new table that an existing one already covers, map to the existing table instead of creating a duplicate — one source of truth for the customer to maintain.
- All content reads live in `src/lib/content.functions.ts` (server functions + `queryOptions`, public Supabase client from `src/lib/public-supabase.ts`); routes prime them with `ensureQueryData` and render with `useSuspenseQuery` — one place to change queries, RLS decides visibility.
- Site chrome (header, banner, footer in `src/components/site/`) is rendered in `__root.tsx` around `<Outlet />` and fed by `settings`, `menus` and `layout` queries primed in the root loader; texts come from the `_global` page sections, `{{key}}` placeholders are filled from `site_settings`, and DB link targets go through `SmartLink` (internal `/slug` → router `/$slug`).
- Pages render through `src/components/sections/PageView.tsx`: `SECTION_COMPONENTS` maps the DB `section_type` to a building block and silently skips unmapped types, so new section types are added there in one place; DB markdown goes through the `Markdown` component (react-markdown, raw HTML skipped).
- `holiday_list` sections get their rows from `holidays` in `getPage` (`attachHolidays`), filtered by the year in the section heading — the customer switches the shown year in one field, no code change.
- Form submissions go through one server function per form (`src/lib/<form>.functions.ts`) that re-validates with that form's shared zod rules (`src/lib/<form>.ts`) and inserts with the public key; `FormSection` picks the form by `form_fields.form_key`. RLS allows anon insert only and DB CHECK constraints back it up — the browser check is UX, the server and DB are the security boundary.
