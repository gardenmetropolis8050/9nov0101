# Fortschritt – Website Kinderkrippe Gigelisuppe

## Projektziel
Die Website der Kinderkrippe Gigelisuppe wird neu nachgebaut. Alle Inhalte (Texte, Bilder, Menü, Kontaktdaten) und Design-Werte (Farben, Schriften, Rundungen) kommen aus der Supabase-Datenbank des Kunden. Der Code enthält nur Bausteine und Standardwerte als Rückfall.

## Vorlage
https://project-migration-hub-phi.vercel.app

## Schritte

| Nr. | Schritt | Status |
| --- | --- | --- |
| 01 | Projektregeln | erledigt |
| 02 | Supabase verbinden & Design-Tabelle | erledigt |
| 03 | Design aus der Datenbank anwenden | erledigt |
| 04 | Einstellungen & Seiten-Tabelle | erledigt |
| 05 | Inhaltsbausteine & Bilder-Speicher | erledigt |
| 06 | Daten im Frontend laden | erledigt |
| 07 | Kopfzeile, Menü, Banner, Fusszeile | erledigt |
| 08 | Seiten-Vorlage | erledigt |
| 09 | Startseite | erledigt |
| 10 | Angebot & Tagesablauf | erledigt |
| 11 | Tarife | erledigt |
| 12 | Häufige Fragen | erledigt |
| 13 | Anmeldung | erledigt |
| 14 | Unser Haus & Feiertage | erledigt |
| 15 | Team | erledigt |
| 16 | Elternstimmen & Geschichte | erledigt |
| 17 | Philosophie-Seiten | erledigt |
| 18 | Alltag | erledigt |
| 19 | Kontakt & Anfahrt | erledigt |
| 20 | Impressum, Datenschutz & Zusammenfügen | erledigt |

## Notizen

### Schritt 01 – erledigt
- `fortschritt.md` angelegt, Projektregeln in `AGENTS.md` ergänzt.
- Leere Startseite durch vorübergehende Seite „Website im Aufbau“ ersetzt.

### Schritt 02 – erledigt
- Tabelle `theme` (genau 1 Zeile, `id = 1`) mit Farben, Schriften, Rundung und Schattenstärke per Migration angelegt; bestehende Tabellen unverändert.
- Öffentlich lesbar (anon/authenticated), Schreiben nur über das Supabase-Dashboard; Startwerte aus der Vorlage eingetragen.

### Schritt 03 – erledigt
- Alle Farben, Schriften, Rundung und Schatten als CSS-Variablen in `src/styles.css` (nur Standardwerte).
- Das Root-Layout lädt die Zeile aus `theme` serverseitig und schreibt sie als `<style>:root{...}</style>` plus Google-Fonts-Links in den Kopf; bei Fehler gelten die Standardwerte.
- „Im Aufbau“-Seite zeigt Titel, Text und Knopf zur Design-Prüfung.

### Schritt 04 – erledigt
- Entscheid des Kunden: keine neuen Tabellen `einstellungen`/`seiten`, die vorhandenen Supabase-Tabellen werden genutzt (nichts gelöscht, nichts doppelt).
- Zuordnung: Seiten = `pages` (alle Seiten inkl. SEO-Texte), Kontakt & SEO-Standard = `site_settings`, Menü & Fusszeile = `navigation` (`hauptmenue`/`footer`), Banner „freie Plätze“ = `availability`; Öffnungszeiten stehen in `content_blocks`.
- Alle vier Tabellen sind öffentlich lesbar (geprüft).

### Schritt 05 – erledigt
- Keine neue Tabelle `abschnitte` und kein neuer Bucket `bilder`: Abschnitte = `page_sections` (mit Inhalten in `content_blocks`, `offers`, `faq`, `tariffs`, `team_members`, `testimonials`, `schedule_entries`, Bilder über `section_images` → `images`); Bilder-Speicher = vorhandener öffentlicher Bucket `website-bilder`. Alles öffentlich lesbar (geprüft).
- Logo der Vorlage liegt bereits identisch in `website-bilder/branding/gigelisuppe-logo.png`; Adresse als `logo_url` in `site_settings` eingetragen.

### Schritt 06 – erledigt
- Zentrale Datenabfragen in `src/lib/content.functions.ts`: Einstellungen (`site_settings`), Menüs (`navigation`, nach Menü gruppiert, Unterpunkte verschachtelt, sortiert) und Seite nach Slug inkl. Abschnitten (`pages` + `page_sections`), je mit `queryOptions`.
- Laden über Route-Loader (`ensureQueryData`) und `useSuspenseQuery`; klare Fehlermeldung mit „Nochmals versuchen“, unbekannte Seite → „nicht gefunden“.
- „Im Aufbau“-Seite zeigt Name und Telefon aus `site_settings` (geprüft).

### Schritt 07 – erledigt
- Kopfzeile (Logo aus `site_settings.logo_url`, Hauptmenü aus `navigation` mit Untermenüs per Maus/Tastatur, aktive Seite hervorgehoben), Handy-Menü, gelbes Banner aus `availability` (nur sichtbare Banner-Einträge, nicht abgelaufen) und Fusszeile (Logo, Kontakt, Öffnungszeiten, Partner, Copyright, Links aus Menü `footer`) im Root-Layout.
- Texte der Kopf-/Fusszeile kommen aus der Seite `_global`; Platzhalter wie `{{telefon}}` werden aus `site_settings` gefüllt. Einfache Seite pro Slug über `/$slug` (bis Schritt 08).

### Schritt 08 – erledigt
- `/` (Seite `home`) und `/$slug` laden die Seite inkl. Abschnitten, Bausteinen, Bildern, Angeboten und Stimmen; 404 bei fehlender, unveröffentlichter oder interner Seite. Tab-Titel und Beschreibung aus `meta_title`/`meta_description` (plus og/twitter); alle 19 Seiten geprüft.
- Bausteine nach Abschnitt-Typ: hero, text (`legal_text`), text_bild (`image_with_cards`), karten (`card`/`cards`/`value_cards`), liste (`tag_list`), galerie (`gallery`), zitat (`testimonials`), info_box, aufruf (`cta`, wenn `show_cta_section`). Andere Typen werden still übersprungen (folgen in späteren Schritten). Markdown sicher ohne HTML.

## Anleitung für den Kunden: Texte, Bilder und Farben ändern
Im Supabase-Dashboard links auf **Table Editor** klicken. Änderungen sind nach dem Neuladen der Website sichtbar.
- **Texte:** Tabelle `page_sections` (Überschriften und Texte der Abschnitte) bzw. `content_blocks`, `faq`, `tariffs`, `team_members` usw. Zeile anklicken, Feld ändern, **Save**. Mit `is_visible` blendest du etwas aus oder ein.
- **Kontakt & Logo:** Tabelle `site_settings`, Spalte `value` ändern (z. B. Telefon, E-Mail, `logo_url`).
- **Bilder:** Links **Storage** → Bucket `website-bilder` → Bild hochladen. Beim Bild auf **Get URL** klicken. Danach in der Tabelle `images` den Pfad (`storage_path`) bzw. bei `site_settings` die Adresse eintragen. Den Bildtext (`alt_text`) bitte immer ausfüllen.
- **Farben, Schriften, Rundungen:** Tabelle `theme`, einzige Zeile. Farben als Hex-Code (z. B. `#c4506a`), Schriften als Google-Fonts-Name (z. B. `Fredoka`).

## Schritt 09 – Startseite (erledigt)
- Inhalte der Startseite lagen bereits wörtlich in der Datenbank (`page_sections` der Seite `home`: Hero „Seit 1998“ mit Bild aus `website-bilder`, 3 Karten in `offers`, Aufruf „Lernen Sie uns kennen“) – nichts neu angelegt oder doppelt.
- Seiten-Vorlage um den Baustein `offers` (farbige Karten mit Symbol) ergänzt; „Im Aufbau“-Seite ist entfernt. `/` im Browser mit der Vorlage verglichen – stimmt überein.

## Schritt 10 – Angebot & Tagesablauf (erledigt)
- Texte beider Seiten lagen bereits wörtlich in der Datenbank (`page_sections` + `content_blocks` für Angebot/Öffnungszeiten, `schedule_entries` für Morgen/Mittag/Nachmittag); einzig „Uhr“ an den Zeitangaben ergänzt. Keine Bilder auf diesen Seiten.
- Seiten-Vorlage um die Bausteine `opening_hours` (Öffnungszeiten-Karte) und `schedule` (Zeitleiste, 3 nebeneinander) ergänzt. Beide Seiten im Browser mit der Vorlage verglichen.

## Schritt 11 – Tarife (erledigt)
- Statt einer neuen Tabelle `tarife` wird die bestehende Tabelle `tariffs` genutzt (gleiche Felder: Kategorie `child_category`, Bezeichnung `label`, Betrag `price_display`, Einheit `unit_label`, Hinweis `description`, Reihenfolge `sort_order`; Lese-Recht + Policy waren schon da). Alle Texte lagen bereits in der Datenbank.
- Neuer Baustein `tarif_tabelle` (in der DB als Abschnitts-Typ `price_card`): einzelner Preis als grosse Preiskarte, mehrere Preise als Kästchen; breite Preiskarte nimmt folgende Karten in eine Seitenspalte. Seite im Browser mit der Vorlage verglichen.
- **Preis ändern:** Supabase → Table Editor → `tariffs` → Spalte `price_display` (so wird der Preis angezeigt, z. B. „Fr. 152.–“). Die Zahlen-Spalten (`price_chf` usw.) sind nur zur Ablage und werden nicht angezeigt.

## Schritt 12 – Häufige Fragen (erledigt)
- Statt einer neuen Tabelle `fragen` wird die bestehende Tabelle `faq` genutzt (Frage `question`, Antwort `answer`, Reihenfolge `sort_order`, sichtbar `is_visible`; Lese-Recht + Policy waren schon da). Alle 7 Fragen lagen bereits wörtlich in der Datenbank.
- Neuer Baustein `fragen_liste` (in der DB als Abschnitts-Typ `faq`): aufklappbare Liste, höchstens eine Frage gleichzeitig offen. Auf- und Zuklappen im Browser geprüft und mit der Vorlage verglichen.

## Schritt 13 – Anmeldung mit Formular (erledigt)
- Texte, Feldbeschriftungen (`form_fields`), Meldungen und die Tabelle `anmeldungen` (mit `created_at`) waren schon da. Ergänzt: Recht zum Einfügen für Besucher (Lesen nur für Admins) und Prüfregeln direkt in der Datenbank.
- Neuer Baustein `form` mit Prüfung im Browser und auf dem Server (Pflichtfelder, Längen, E-Mail, Datum), Erfolgs- und Fehlermeldungen aus der DB; Telefon-Links in DB-Texten funktionieren jetzt. Testanmeldung gespeichert, öffentlich nicht lesbar geprüft, danach wieder gelöscht.
- **Anmeldungen ansehen:** Supabase → Table Editor → `anmeldungen` (neueste zuerst nach `created_at` sortieren). Eine E-Mail-Benachrichtigung gibt es noch nicht.

## Schritt 14 – Unser Haus & Feiertage (erledigt)
- Texte und alle 16 Bilder (mit Alt-Texten, im Bucket `website-bilder`) von „Unser Haus“ lagen bereits wörtlich in der Datenbank; Galerie und Aufruf werden angezeigt. Statt einer neuen Tabelle `feiertage` wird die bestehende Tabelle `holidays` genutzt (Lese-Recht + Policy waren schon da).
- Neuer Baustein `feiertage_liste` (in der DB Abschnitts-Typ `holiday_list`): zeigt die Feiertage des Jahres aus der Abschnitts-Überschrift (`2026`, neu eingetragen) mit Wochentag/Datum und Hinweis, „Keine Betriebsferien“ als Karte daneben. Beide Seiten im Browser mit der Vorlage verglichen.
- **Feiertage ändern:** Supabase → Table Editor → `holidays` (`title`, `start_date`, `description`, Jahr `display_year`). Neues Jahr anzeigen: in `page_sections` beim Abschnitt `feiertage-liste` die Überschrift (`heading`) auf das neue Jahr setzen.

## Schritt 15 – Team (erledigt)
- Statt einer neuen Tabelle `team` wird die bestehende Tabelle `team_members` genutzt (Name `name`, Funktion `role`, Foto über `image_id` → `images`, Reihenfolge `sort_order`, aktiv `is_visible`; Lese-Recht + Policy waren schon da). Alle 13 Personen, Texte und 11 Fotos (Bucket `website-bilder/team`) lagen bereits in der Datenbank; Janette G. und Norbert D. haben wie im Original kein Foto, sondern Initialen (`initials`).
- Neuer Baustein `team_raster` (in der DB Abschnitts-Typ `team_group`): Foto oder Initialen, Name und Funktion, bis 5 nebeneinander. Seite im Browser mit der Vorlage verglichen.
- **Team ändern:** Supabase → Table Editor → `team_members`. Neues Foto: in Storage `website-bilder/team` hochladen, in `images` eine Zeile mit `storage_path` und `alt_text` anlegen und deren `id` bei der Person in `image_id` eintragen.

## Schritt 16 – Elternstimmen & Geschichte (erledigt)
- Statt einer neuen Tabelle `elternstimmen` wird die bestehende Tabelle `testimonials` genutzt (Text `body`, Name `author`, Reihenfolge `sort_order`; Lese-Recht + Policy waren schon da). Alle 7 Stimmen und die Texte der Geschichte (`content_blocks` vom Typ `timeline_entry` + `signature`) lagen bereits wörtlich in der Datenbank; auf beiden Seiten gibt es keine Bilder.
- Baustein `stimmen_liste` (DB-Typ `testimonials`) zeigt die Stimmen jetzt in zwei Spalten wie im Original; neuer Baustein `zeitleiste` (DB-Typ `timeline`) mit farbigen Punkten und Unterschrift. Beide Seiten im Browser mit der Vorlage verglichen.
- **Stimme ändern/neu:** Supabase → Table Editor → `testimonials` (Abschnitt `section_id` 40). **Geschichte ändern:** `content_blocks` mit `section_id` 42.

## Schritt 17 – Philosophie-Seiten (erledigt)
- Texte und Bilder von Leitsätze (17 Werte in `content_blocks`), Ernährung (2 Textkarten + 7 Bilder) und Förderung (Bild + 3 Karten) lagen bereits wörtlich in der Datenbank bzw. im Bucket `website-bilder`. Ergänzt: Nummern „01–17“ (`subtitle`) und Kartenfarben (`color_tone`) der Leitsätze wie im Original.
- Bausteine minimal angepasst: Karten zeigen eine Nummer/Unterzeile aus `subtitle`; Galeriebilder sind flacher (wie im Original, gilt auch für „Unser Haus“). Alle drei Seiten im Browser mit der Vorlage verglichen.

## Schritt 18 – Alltag mit Bildergalerie (erledigt)
- Alle Texte (Kopfbereich, 10 Tätigkeiten, 2 Natur-Karten) und die 16 Fotos „Impressionen“ (Waldtag, Hasenbesuch, Ausflug, Garten – mit Alt-Texten, im eigenen Bucket `website-bilder/alltag`) lagen bereits wörtlich in der Datenbank – nichts doppelt angelegt.
- Baustein `galerie` ergänzt: Bilder laden verzögert, Klick öffnet das Bild gross mit Bildtext (schliessen per Klick daneben, X oder Esc; gilt für alle Galerien). Seite im Browser mit der Vorlage verglichen.

## Schritt 19 – Kontakt & Anfahrt mit Kontaktformular (erledigt)
- Texte beider Seiten lagen bereits wörtlich in der Datenbank (keine Bilder). Kontaktdaten kommen aus `site_settings`, die Kartenadresse neu aus `site_settings.karte_url`; die Google-Karte lädt erst nach Klick auf „Karte laden“ (mit Datenschutz-Hinweis).
- Neu: Kontaktformular „Schreiben Sie uns“ (Name*, E-Mail*, Telefon, Nachricht*; Felder in `form_fields`, Texte in `content_blocks`) → Tabelle `kontakt_nachrichten` (Besucher dürfen nur senden, lesen nur Admins; Prüfung im Browser, auf dem Server und in der DB). Testnachricht gespeichert, öffentlich nicht lesbar geprüft, danach gelöscht.
- **Nachrichten ansehen:** Supabase → Table Editor → `kontakt_nachrichten` (nach `created_at` sortieren). Eine E-Mail-Benachrichtigung gibt es noch nicht.

## Nächster Schritt
**Alle Schritte erledigt – Website bereit zum Veröffentlichen.**

### Schritt 20 – erledigt
- Projekt in neues Lovable-Projekt übernommen, mit bestehender Datenbank verbunden.
- Impressum und Datenschutz kommen vollständig aus der Datenbank; alle Seiten geprüft (keine leeren Seiten, 404 funktioniert).

## Anleitung für den Kunden – welche Tabelle steuert was
- `theme`: Farben, Schriften, Rundungen
- `site_settings`: Kontaktdaten, Telefon, Adresse, Öffnungszeiten
- `pages`: Seiten, Titel, Beschreibungen
- `page_sections` / `content_blocks`: Texte und Bausteine jeder Seite
- `navigation`: Menü und Fusszeilen-Links
- `images` / `section_images`: Bilder und Alt-Texte
- `tariffs`, `faq`, `team_members`, `testimonials`, `holidays`, `schedule_entries`, `offers`, `availability`: jeweilige Listen
- `anmeldungen`, `kontakt_nachrichten`: eingegangene Formulare
